// Simple seat selection functionality
document.addEventListener('DOMContentLoaded', function() {
    console.log('Seat selection script loaded');
    
    const seats = document.querySelectorAll('.seat');
    const selectedSeats = [];
    
    seats.forEach(seat => {
        seat.addEventListener('click', function() {
            if (this.classList.contains('booked')) {
                alert('This seat is already booked!');
                return;
            }
            
            if (this.classList.contains('selected')) {
                // Deselect seat
                this.classList.remove('selected');
                const seatId = this.dataset.row + ',' + this.dataset.col;
                const index = selectedSeats.indexOf(seatId);
                if (index > -1) {
                    selectedSeats.splice(index, 1);
                }
            } else {
                // Select seat
                this.classList.add('selected');
                selectedSeats.push(this.dataset.row + ',' + this.dataset.col);
            }
            
            updateSelectionSummary();
        });
    });
    
    function updateSelectionSummary() {
        const summary = document.getElementById('selected-seats');
        const formInput = document.querySelector('input[name="seats"]');
        const submitButton = document.querySelector('#booking-form button');
        
        if (selectedSeats.length === 0) {
            summary.innerHTML = '<p class="text-muted">No seats selected</p>';
            submitButton.disabled = true;
        } else {
            summary.innerHTML = `
                <h6>Selected Seats (${selectedSeats.length}):</h6>
                <p>${selectedSeats.map(seat => {
                    const [row, col] = seat.split(',');
                    return `Row ${parseInt(row) + 1}, Seat ${parseInt(col) + 1}`;
                }).join('<br>')}</p>
            `;
            submitButton.disabled = false;
        }
        
        // Update form data
        formInput.value = JSON.stringify(selectedSeats.map(seat => {
            const [row, col] = seat.split(',');
            return { row: parseInt(row), col: parseInt(col) };
        }));
    }
});