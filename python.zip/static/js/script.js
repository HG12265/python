// Simple seat selection - CineBook
document.addEventListener('DOMContentLoaded', function() {
    console.log("CineBook script loaded...");
    
    // Seat selection code
    const seats = document.querySelectorAll('.seat');
    const bookingForm = document.getElementById('booking-form');
    
    if (seats.length > 0 && bookingForm) {
        console.log("Seat selection initializing...");
        
        const selectedSeats = [];
        const seatsInput = bookingForm.querySelector('input[name="seats"]');
        const submitButton = bookingForm.querySelector('button[type="submit"]');
        const selectedSeatsContainer = document.getElementById('selected-seats');
        const priceSummary = document.getElementById('price-summary');
        
        // Seat prices
        const seatPrices = {
            'Standard': 100.0,
            'Premium': 150.0,
            'VIP': 200.0
        };
        
        seats.forEach(seat => {
            if (!seat.classList.contains('booked')) {
                seat.addEventListener('click', function() {
                    const row = this.dataset.row;
                    const col = this.dataset.col;
                    const seatId = `${row},${col}`;
                    
                    if (this.classList.contains('selected')) {
                        // Deselect seat
                        this.classList.remove('selected');
                        const index = selectedSeats.findIndex(s => s.id === seatId);
                        if (index !== -1) {
                            selectedSeats.splice(index, 1);
                        }
                    } else {
                        // Select seat
                        this.classList.add('selected');
                        
                        // Determine seat type
                        let type = 'Standard';
                        if (this.classList.contains('premium')) type = 'Premium';
                        if (this.classList.contains('vip')) type = 'VIP';
                        
                        selectedSeats.push({
                            id: seatId,
                            row: parseInt(row),
                            col: parseInt(col),
                            type: type,
                            price: seatPrices[type]
                        });
                    }
                    
                    updateBookingSummary();
                });
            }
        });
        
        function updateBookingSummary() {
            // Update selected seats display
            if (selectedSeats.length === 0) {
                selectedSeatsContainer.innerHTML = '<p class="mb-1 text-muted">No seats selected</p>';
            } else {
                let html = '<h6>Selected Seats:</h6>';
                selectedSeats.forEach(seat => {
                    html += `<div class="d-flex justify-content-between mb-1">
                        <span>Row ${seat.row + 1}, Seat ${seat.col + 1} (${seat.type})</span>
                        <span>₹${seat.price.toFixed(2)}</span>
                    </div>`;
                });
                selectedSeatsContainer.innerHTML = html;
            }
            
            // Update price summary
            const subtotal = selectedSeats.reduce((sum, seat) => sum + seat.price, 0);
            
            priceSummary.innerHTML = `
                <div class="d-flex justify-content-between mb-1">
                    <span>Subtotal:</span>
                    <span>₹${subtotal.toFixed(2)}</span>
                </div>
                <hr>
                <div class="d-flex justify-content-between fw-bold">
                    <span>Total:</span>
                    <span>₹${subtotal.toFixed(2)}</span>
                </div>
            `;
            
            // Update form data and button state
            seatsInput.value = JSON.stringify(selectedSeats.map(seat => ({
                row: seat.row,
                col: seat.col
            })));
            
            submitButton.disabled = selectedSeats.length === 0;
        }
        
        // Handle form submission
        bookingForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            if (selectedSeats.length === 0) {
                alert('Please select at least one seat');
                return;
            }
            
            const formData = new FormData(this);
            
            fetch('/book', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    window.location.href = '/booking-confirmation/' + data.booking_id;
                } else {
                    alert('Error: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred while booking tickets');
            });
        });
    }
});