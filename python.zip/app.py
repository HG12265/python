from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify, send_file
from flask_sqlalchemy import SQLAlchemy

from werkzeug.security import generate_password_hash, check_password_hash

from reportlab.pdfgen import canvas
import pandas as pd

import numpy as np

from datetime import datetime, timedelta

import json

import io

import os

import sqlite3


app = Flask(__name__)

app.secret_key = 'cinema_booking_secret_key_2023'

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///cinema.db'

app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False



db = SQLAlchemy(app)



# ============================================================

# DATABASE MODELS

# ============================================================



class User(db.Model):

    id = db.Column(db.Integer, primary_key=True)

    username = db.Column(db.String(80), unique=True, nullable=False)

    password_hash = db.Column(db.String(120), nullable=False)

    email = db.Column(db.String(120), nullable=False)

    full_name = db.Column(db.String(100))

    phone = db.Column(db.String(15))

    role = db.Column(db.String(20), default='user')

    created_at = db.Column(db.DateTime, default=datetime.utcnow)



    def set_password(self, password):

        self.password_hash = generate_password_hash(password)



    def check_password(self, password):

        return check_password_hash(self.password_hash, password)



class Movie(db.Model):

    id = db.Column(db.Integer, primary_key=True)

    title = db.Column(db.String(100), nullable=False)

    genre = db.Column(db.String(50), nullable=False)

    duration = db.Column(db.Integer, nullable=False)  # in minutes

    description = db.Column(db.Text)

    poster_url = db.Column(db.String(200))

    language = db.Column(db.String(50), default='English')

    rating = db.Column(db.Float, default=0.0)

    is_active = db.Column(db.Boolean, default=True)



class Showtime(db.Model):

    id = db.Column(db.Integer, primary_key=True)

    movie_id = db.Column(db.Integer, db.ForeignKey('movie.id'), nullable=False)

    time = db.Column(db.DateTime, nullable=False)

    hall = db.Column(db.String(50), nullable=False)

    rows = db.Column(db.Integer, nullable=False)

    cols = db.Column(db.Integer, nullable=False)

    seat_categories = db.Column(db.Text)  # JSON string of seat categories

    price_standard = db.Column(db.Float, default=100.0)

    price_premium = db.Column(db.Float, default=150.0)

    price_vip = db.Column(db.Float, default=200.0)

    

    movie = db.relationship('Movie', backref=db.backref('showtimes', lazy=True))



class SeatLayout(db.Model):

    id = db.Column(db.Integer, primary_key=True)

    showtime_id = db.Column(db.Integer, db.ForeignKey('showtime.id'), unique=True, nullable=False)

    layout = db.Column(db.Text, nullable=False)  # JSON string of seat layout

    

    showtime = db.relationship('Showtime', backref=db.backref('seat_layout', uselist=False))



class Booking(db.Model):

    id = db.Column(db.Integer, primary_key=True)

    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)

    showtime_id = db.Column(db.Integer, db.ForeignKey('showtime.id'), nullable=False)

    seats = db.Column(db.Text, nullable=False)  # JSON string of booked seats

    total_price = db.Column(db.Float, nullable=False)

    booking_time = db.Column(db.DateTime, default=datetime.utcnow)

    status = db.Column(db.String(20), default='confirmed')  # confirmed, cancelled

    

    user = db.relationship('User', backref=db.backref('bookings', lazy=True))

    showtime = db.relationship('Showtime', backref=db.backref('bookings', lazy=True))



# ============================================================

# HELPER FUNCTIONS

# ============================================================



def create_seat_layout(rows, cols, seat_categories=None):

    """

    Create a seat layout with categories

    Seat codes:

    0: Standard Available, 1: Standard Booked

    2: Premium Available, 3: Premium Booked

    4: VIP Available, 5: VIP Booked

    """

    layout = np.zeros((rows, cols), dtype=int).tolist()

    

    if seat_categories:

        for cat, positions in seat_categories.items():

            for r, c in positions:

                if 0 <= r < rows and 0 <= c < cols:

                    if cat == "premium":

                        layout[r][c] = 2

                    elif cat == "vip":

                        layout[r][c] = 4

    return layout



def get_seat_type(seat_code):

    """Get seat type from seat code"""

    if seat_code in [0, 1]:

        return "Standard"

    elif seat_code in [2, 3]:

        return "Premium"

    elif seat_code in [4, 5]:

        return "VIP"

    return "Standard"



def get_seat_price(showtime, seat_type):

    """Get price for a seat type"""

    if seat_type == "Standard":

        return showtime.price_standard

    elif seat_type == "Premium":

        return showtime.price_premium

    elif seat_type == "VIP":

        return showtime.price_vip

    return showtime.price_standard



# Custom template filter

@app.template_filter('fromjson')

def from_json_filter(value):

    return json.loads(value)



# ============================================================

# ROUTES

# ============================================================



@app.route('/')

def index():

    movies = Movie.query.filter_by(is_active=True).all()

    now_showing = movies[:4]  # First 4 movies

    coming_soon = movies[4:] if len(movies) > 4 else []  # Rest as coming soon

    

    # Get featured showtimes for today and tomorrow

    today = datetime.now().date()

    tomorrow = today + timedelta(days=1)

    

    today_showtimes = Showtime.query.filter(

        db.func.date(Showtime.time) == today

    ).join(Movie).filter(Movie.is_active == True).all()

    

    tomorrow_showtimes = Showtime.query.filter(

        db.func.date(Showtime.time) == tomorrow

    ).join(Movie).filter(Movie.is_active == True).all()

    

    return render_template('index.html', 

                         now_showing=now_showing,

                         coming_soon=coming_soon,

                         today_showtimes=today_showtimes,

                         tomorrow_showtimes=tomorrow_showtimes,

                         user=session.get('user'))



@app.route('/movies')

def movies():

    all_movies = Movie.query.filter_by(is_active=True).all()

    return render_template('movies.html', movies=all_movies, user=session.get('user'))



@app.route('/movie/<int:movie_id>')

def movie_detail(movie_id):

    movie = Movie.query.get_or_404(movie_id)

    

    # Get showtimes for the next 7 days

    start_date = datetime.now().date()

    end_date = start_date + timedelta(days=7)

    

    showtimes = Showtime.query.filter(

        Showtime.movie_id == movie_id,

        Showtime.time >= start_date,

        Showtime.time <= end_date

    ).order_by(Showtime.time).all()

    

    # Group showtimes by date

    showtimes_by_date = {}

    for st in showtimes:

        date_str = st.time.strftime('%Y-%m-%d')

        if date_str not in showtimes_by_date:

            showtimes_by_date[date_str] = []

        showtimes_by_date[date_str].append(st)

    

    return render_template('movie_detail.html', 

                         movie=movie, 

                         showtimes_by_date=showtimes_by_date,

                         user=session.get('user'))



@app.route('/showtime/<int:showtime_id>')

def showtime_detail(showtime_id):

    if 'user_id' not in session:

        flash('Please login to book tickets', 'error')

        return redirect(url_for('login'))

    

    showtime = Showtime.query.get_or_404(showtime_id)

    movie = Movie.query.get(showtime.movie_id)

    

    # Get or create seat layout

    seat_layout = SeatLayout.query.filter_by(showtime_id=showtime_id).first()

    if not seat_layout:

        # Create initial seat layout

        categories = json.loads(showtime.seat_categories) if showtime.seat_categories else {}

        layout = create_seat_layout(showtime.rows, showtime.cols, categories)

        

        seat_layout = SeatLayout(showtime_id=showtime_id, layout=json.dumps(layout))

        db.session.add(seat_layout)

        db.session.commit()

    else:

        layout = json.loads(seat_layout.layout)

    

    return render_template('showtime.html', 

                         showtime=showtime, 

                         movie=movie, 

                         layout=layout,

                         user=session.get('user'))



@app.route('/book', methods=['POST'])

def book_tickets():

    if 'user_id' not in session:

        return jsonify({'success': False, 'message': 'Please login first'})

    

    try:

        showtime_id = int(request.form['showtime_id'])

        seats = json.loads(request.form['seats'])

        

        showtime = Showtime.query.get_or_404(showtime_id)

        seat_layout = SeatLayout.query.filter_by(showtime_id=showtime_id).first()

        

        if not seat_layout:

            return jsonify({'success': False, 'message': 'Seat layout not found'})

        

        layout = json.loads(seat_layout.layout)

        total_price = 0

        booking_seats = []

        

        # Check if seats are available and calculate price

        for seat in seats:

            row, col = seat['row'], seat['col']

            if layout[row][col] % 2 == 1:  # Already booked

                return jsonify({'success': False, 'message': f'Seat ({row+1}, {col+1}) is already booked'})

            

            seat_type = get_seat_type(layout[row][col])

            price = get_seat_price(showtime, seat_type)

            total_price += price

            

            booking_seats.append({

                'row': row,

                'col': col,

                'type': seat_type,

                'price': price

            })

        

        # Mark seats as booked

        for seat in seats:

            row, col = seat['row'], seat['col']

            layout[row][col] += 1  # Mark as booked

        

        # Update seat layout

        seat_layout.layout = json.dumps(layout)

        

        # Create booking

        booking = Booking(

            user_id=session['user_id'],

            showtime_id=showtime_id,

            seats=json.dumps(booking_seats),

            total_price=total_price

        )

        

        db.session.add(booking)

        db.session.commit()

        

        return jsonify({

            'success': True, 

            'message': 'Booking successful!', 

            'booking_id': booking.id,

            'total_price': total_price

        })

        

    except Exception as e:

        return jsonify({'success': False, 'message': str(e)})



@app.route('/booking-confirmation/<int:booking_id>')

def booking_confirmation(booking_id):

    booking = Booking.query.get_or_404(booking_id)

    

    # Check if user owns this booking

    if 'user_id' not in session or booking.user_id != session['user_id']:

        flash('You are not authorized to view this booking', 'error')

        return redirect(url_for('index'))

    

    return render_template('booking_confirmation.html', 

                         booking=booking,

                         user=session.get('user'))



@app.route('/my-bookings')

def my_bookings():

    if 'user_id' not in session:

        flash('Please login to view your bookings', 'error')

        return redirect(url_for('login'))

    

    bookings = Booking.query.filter_by(user_id=session['user_id']).order_by(Booking.booking_time.desc()).all()

    return render_template('my_bookings.html', 

                         bookings=bookings,

                         user=session.get('user'))



@app.route('/cancel-booking/<int:booking_id>', methods=['POST'])

def cancel_booking(booking_id):

    if 'user_id' not in session:

        return jsonify({'success': False, 'message': 'Please login first'})

    

    booking = Booking.query.get_or_404(booking_id)

    

    if booking.user_id != session['user_id']:

        return jsonify({'success': False, 'message': 'You are not authorized to cancel this booking'})

    

    if booking.status == 'cancelled':

        return jsonify({'success': False, 'message': 'Booking is already cancelled'})

    

    try:

        seat_layout = SeatLayout.query.filter_by(showtime_id=booking.showtime_id).first()

        layout = json.loads(seat_layout.layout)

        booked_seats = json.loads(booking.seats)

        

        for seat in booked_seats:

            row = seat['row']

            col = seat['col']

            if layout[row][col] % 2 == 1:

                layout[row][col] -= 1

        

        seat_layout.layout = json.dumps(layout)

        booking.status = 'cancelled'

        

        db.session.commit()

        

        return jsonify({'success': True, 'message': 'Booking cancelled successfully'})

    

    except Exception as e:

        db.session.rollback()

        return jsonify({'success': False, 'message': str(e)})

@app.route('/download_ticket/<int:booking_id>')
def download_ticket(booking_id):
    # Connect to DB
    conn = sqlite3.connect("instance/cinema.db")
    cursor = conn.cursor()

    # Fetch booking + movie + showtime + user details
    cursor.execute("""
        SELECT b.id, u.username, m.title, s.time, b.seats, b.total_price, s.hall
        FROM booking b
        JOIN user u ON b.user_id = u.id
        JOIN showtime s ON b.showtime_id = s.id
        JOIN movie m ON s.movie_id = m.id
        WHERE b.id = ?
    """, (booking_id,))
    booking = cursor.fetchone()
    conn.close()

    if not booking:
        return "Booking not found", 404

    # Unpack details
    (bid, username, movie_name, showtime, seats, amount, hall) = booking

    # Create PDF in memory
    buffer = io.BytesIO()
    p = canvas.Canvas(buffer)

    # Header
    p.setFont("Helvetica-Bold", 18)
    p.drawString(200, 800, "🎟️ CINEMA TICKET 🎟️")

    # Ticket details
    p.setFont("Helvetica", 12)
    p.drawString(100, 760, f"Theater (Hall): {hall}")
    p.drawString(100, 740, f"Movie: {movie_name}")
    p.drawString(100, 720, f"Showtime: {showtime}")
    p.drawString(100, 700, f"Seats: {seats}")
    p.drawString(100, 680, f"Username: {username}")
    p.drawString(100, 660, f"Payment: ₹{amount}")
    p.drawString(100, 640, f"Booking ID: {bid}")

    # Footer
    p.setFont("Helvetica-Oblique", 10)
    p.drawString(100, 600, "Enjoy your movie! 🍿")

    p.showPage()
    p.save()
    buffer.seek(0)

    # Return PDF
    return send_file(
        buffer,
        as_attachment=True,
        download_name=f"ticket_{bid}.pdf",
        mimetype='application/pdf'
    )

@app.route('/register', methods=['GET', 'POST'])

def register():

    if request.method == 'POST':

        username = request.form['username']

        password = request.form['password']

        email = request.form['email']

        full_name = request.form.get('full_name', '')

        phone = request.form.get('phone', '')

        

        # Check if user exists

        if User.query.filter_by(username=username).first():

            flash('Username already exists', 'error')

            return redirect(url_for('register'))

        

        if User.query.filter_by(email=email).first():

            flash('Email already registered', 'error')

            return redirect(url_for('register'))

        

        # Create new user

        user = User(username=username, email=email, full_name=full_name, phone=phone)

        user.set_password(password)

        db.session.add(user)

        db.session.commit()

        

        flash('Registration successful! Please login.', 'success')

        return redirect(url_for('login'))

    

    return render_template('register.html', user=session.get('user'))



@app.route('/login', methods=['GET', 'POST'])

def login():

    if request.method == 'POST':

        username = request.form['username']

        password = request.form['password']

        

        user = User.query.filter_by(username=username).first()

        

        if user and user.check_password(password):

            session['user_id'] = user.id

            session['user'] = {

                'id': user.id,

                'username': user.username,

                'email': user.email,

                'full_name': user.full_name,

                'role': user.role

            }

            flash('Login successful!', 'success')

            return redirect(url_for('index'))

        else:

            flash('Invalid username or password', 'error')

    

    return render_template('login.html', user=session.get('user'))



@app.route('/logout')

def logout():

    session.pop('user_id', None)

    session.pop('user', None)

    flash('You have been logged out', 'info')

    return redirect(url_for('index'))



# ============================================================

# INITIAL DATA SETUP

# ============================================================



def init_db():

    """Initialize database with sample data"""

    db.create_all()

    

    # Create admin user if not exists

    if not User.query.filter_by(username='admin').first():

        admin = User(username='admin', email='admin@cinema.com', full_name='Admin User', role='admin')

        admin.set_password('admin123')

        db.session.add(admin)

    

    # Add sample movies if none exist

    if not Movie.query.first():

        movies = [

            Movie(

                title='Avatar: The Way of Water',

                genre='Sci-Fi',

                duration=192,

                description='Jake Sully lives with his newfound family formed on the planet of Pandora. Once a familiar threat returns to finish what was previously started, Jake must work with Neytiri and the army of the Na\'vi race to protect their planet.',

                poster_url='/static/images/avatar.jpg',

                language='English',

                rating=8.2

            ),

            Movie(

                title='John Wick: Chapter 4',

                genre='Action',

                duration=169,

                description='John Wick uncovers a path to defeating The High Table. But before he can earn his freedom, Wick must face off against a new enemy with powerful alliances across the globe and forces that turn old friends into foes.',

                poster_url='/static/images/johnwick.jpg',

                language='English',

                rating=8.5

            ),

            Movie(

                title='The Super Mario Bros. Movie',

                genre='Animation',

                duration=92,

                description='A plumber named Mario travels through an underground labyrinth with his brother, Luigi, trying to save a captured princess.',

                poster_url='/static/images/mario.jpg',

                language='English',

                rating=7.5

            ),

            Movie(

                title='Oppenheimer',

                genre='Biography',

                duration=180,

                description='The story of American scientist J. Robert Oppenheimer and his role in the development of the atomic bomb.',

                poster_url='/static/images/oppenheimer.jpg',

                language='English',

                rating=8.8

            ),

            Movie(

                title='Fast X',

                genre='Action',

                duration=141,

                description='Dom Toretto and his family are targeted by the vengeful son of drug kingpin Hernan Reyes.',

                poster_url='/static/images/fastx.jpg',

                language='English',

                rating=6.9

            ),

            Movie(

                title='The Little Mermaid',

                genre='Fantasy',

                duration=135,

                description='A young mermaid makes a deal with a sea witch to trade her beautiful voice for human legs so she can discover the world above water and impress a prince.',

                poster_url='/static/images/mermaid.jpg',

                language='English',

                rating=7.5

            )

        ]

        db.session.add_all(movies)

        db.session.commit()

    

    # Add sample showtimes if none exist

    if not Showtime.query.first():

        movie1 = Movie.query.filter_by(title='Avatar: The Way of Water').first()

        movie2 = Movie.query.filter_by(title='John Wick: Chapter 4').first()

        

        if movie1 and movie2:

            # Create showtimes for the next 7 days

            now = datetime.now()

            showtimes = []

            

            for i in range(7):

                date = now + timedelta(days=i)

                

                # Avatar showtimes

                showtimes.append(Showtime(

                    movie_id=movie1.id,

                    time=datetime(date.year, date.month, date.day, 10, 0),

                    hall='Hall 1',

                    rows=8,

                    cols=10,

                    seat_categories=json.dumps({

                        "premium": [(0,0), (0,1), (0,8), (0,9)],

                        "vip": [(3,4), (3,5), (4,4), (4,5)]

                    }),

                    price_standard=120.0,

                    price_premium=180.0,

                    price_vip=250.0

                ))

                

                showtimes.append(Showtime(

                    movie_id=movie1.id,

                    time=datetime(date.year, date.month, date.day, 16, 30),

                    hall='Hall 2',

                    rows=8,

                    cols=10,

                    seat_categories=json.dumps({

                        "premium": [(0,0), (0,1), (0,8), (0,9)],

                        "vip": [(3,4), (3,5), (4,4), (4,5)]

                    }),

                    price_standard=120.0,

                    price_premium=180.0,

                    price_vip=250.0

                ))

                

                # John Wick showtimes

                showtimes.append(Showtime(

                    movie_id=movie2.id,

                    time=datetime(date.year, date.month, date.day, 13, 15),

                    hall='Hall 3',

                    rows=8,

                    cols=10,

                    seat_categories=json.dumps({

                        "premium": [(0,0), (0,1), (0,8), (0,9)],

                        "vip": [(3,4), (3,5), (4,4), (4,5)]

                    }),

                    price_standard=110.0,

                    price_premium=160.0,

                    price_vip=220.0

                ))

                

                showtimes.append(Showtime(

                    movie_id=movie2.id,

                    time=datetime(date.year, date.month, date.day, 19, 45),

                    hall='Hall 1',

                    rows=8,

                    cols=10,

                    seat_categories=json.dumps({

                        "premium": [(0,0), (0,1), (0,8), (0,9)],

                        "vip": [(3,4), (3,5), (4,4), (4,5)]

                    }),

                    price_standard=110.0,

                    price_premium=160.0,

                    price_vip=220.0

                ))

            

            db.session.add_all(showtimes)

    

    db.session.commit()



# ============================================================

# RUN APPLICATION

# ============================================================



if __name__ == '__main__':

    with app.app_context():

        init_db()

    app.run(debug=True)