document.addEventListener('DOMContentLoaded', function() {
    const seatMapContainer = document.getElementById('seat-map-container');
    if (!seatMapContainer) return;

    const showtimeId = seatMapContainer.dataset.showtimeId;
    const layout = JSON.parse(seatMapContainer.dataset.layout);
    const priceStandard = parseFloat(seatMapContainer.dataset.priceStandard);
    const pricePremium = parseFloat(seatMapContainer.dataset.pricePremium);
    const priceVip = parseFloat(seatMapContainer.dataset.priceVip);

    const selectedSeats = new Set();
    let totalPrice = 0;

    const selectedCountEl = document.getElementById('selected-count');
    const selectedTotalEl = document.getElementById('selected-total');
    const payButton = document.getElementById('pay-button');

    function getSeatInfo(code) {
        if ([0, 1].includes(code)) return { type: 'standard', price: priceStandard, booked: code === 1 };
        if ([2, 3].includes(code)) return { type: 'premium', price: pricePremium, booked: code === 3 };
        if ([4, 5].includes(code)) return { type: 'vip', price: priceVip, booked: code === 5 };
        return { type: 'standard', price: priceStandard, booked: false };
    }

    // Render Seat Map
    layout.forEach((row, r) => {
        const rowEl = document.createElement('div');
        rowEl.className = 'seat-row';
        row.forEach((code, c) => {
            const seat = document.createElement('button');
            const seatInfo = getSeatInfo(code);
            seat.className = `seat ${seatInfo.type}`;
            seat.dataset.row = r;
            seat.dataset.col = c;
            seat.dataset.price = seatInfo.price;
            
            if (seatInfo.booked) {
                seat.classList.add('booked');
                seat.disabled = true;
            }

            seat.addEventListener('click', () => {
                const seatId = `${r}-${c}`;
                if (selectedSeats.has(seatId)) {
                    selectedSeats.delete(seatId);
                    seat.classList.remove('selected');
                    totalPrice -= seatInfo.price;
                } else {
                    selectedSeats.add(seatId);
                    seat.classList.add('selected');
                    totalPrice += seatInfo.price;
                }
                updateSummary();
            });

            rowEl.appendChild(seat);
        });
        seatMapContainer.appendChild(rowEl);
    });

    function updateSummary() {
        selectedCountEl.textContent = selectedSeats.size;
        selectedTotalEl.textContent = totalPrice.toFixed(2);
        payButton.disabled = selectedSeats.size === 0;
    }

    payButton.addEventListener('click', async () => {
        if (selectedSeats.size === 0) {
            alert('Please select at least one seat.');
            return;
        }

        payButton.disabled = true;
        payButton.innerHTML = '<span class="loading"></span> Processing...';
        
        const seatsToBook = Array.from(selectedSeats).map(id => {
            const [row, col] = id.split('-').map(Number);
            return { row, col };
        });

        try {
            const response = await fetch('/process-payment', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    showtime_id: showtimeId,
                    seats: seatsToBook,
                    payment_method: 'online'
                })
            });

            const result = await response.json();

            if (result.success) {
                window.location.href = `/booking-confirmation/${result.booking_id}`;
            } else {
                alert(`Booking failed: ${result.message}`);
                payButton.disabled = false;
                payButton.textContent = 'Proceed to Pay';
            }
        } catch (error) {
            console.error('Payment error:', error);
            alert('An error occurred. Please try again.');
            payButton.disabled = false;
            payButton.textContent = 'Proceed to Pay';
        }
    });

    updateSummary();
});