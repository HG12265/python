from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify, send_file
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import json
import os
import stripe
import qrcode
from io import BytesIO
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from authlib.integrations.flask_client import OAuth
import requests
from functools import wraps

app = Flask(__name__)
app.secret_key = 'cinema_booking_secret_key_2023'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///cinema.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['UPLOAD_FOLDER'] = 'static/uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size

# Stripe configuration
app.config['STRIPE_PUBLIC_KEY'] = 'pk_test_51S7c77CGf8UwZpCG7qrEmq2WkRkeMdXo1KLQHyvzOEjvVd3P8orlCHhPGtd5oKGWRURKYuZr344VZbIvYTd6GOBW00PYqlzxxT'
app.config['STRIPE_SECRET_KEY'] = 'sk_test_51S7c77CGf8UwZpCGxIH0UsMf6yo7MNPqyCpD6pVtZMSXumZvEMHmPqWRzjCyCRDV642U72JSDoBWUKkdecr2Mn8I00OkqAvgtS'
stripe.api_key = app.config['STRIPE_SECRET_KEY']

# Email configuration
app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USERNAME'] = 'gowtham114411@gmail.com'
app.config['MAIL_PASSWORD'] = 'GOWtham2004@'

# OAuth configuration
app.config['GOOGLE_CLIENT_ID'] = '636577333858-3si28hco6o11t7f9ibq5tihcgbfmki8h.apps.googleusercontent.com'
app.config['GOOGLE_CLIENT_SECRET'] = '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'

db = SQLAlchemy(app)
oauth = OAuth(app)

# Google OAuth setup
google = oauth.register(
    name='google',
    client_id=app.config['GOOGLE_CLIENT_ID'],
    client_secret=app.config['GOOGLE_CLIENT_SECRET'],
    access_token_url='https://accounts.google.com/o/oauth2/token',
    access_token_params=None,
    authorize_url='https://accounts.google.com/o/oauth2/auth',
    authorize_params=None,
    api_base_url='https://www.googleapis.com/oauth2/v1/',
    client_kwargs={'scope': 'openid email profile'},
)

# ============================================================
# DATABASE MODELS (UPDATED)
# ============================================================

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(120), nullable=True)  # Nullable for social login
    email = db.Column(db.String(120), nullable=False)
    full_name = db.Column(db.String(100))
    phone = db.Column(db.String(15))
    role = db.Column(db.String(20), default='user')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    avatar = db.Column(db.String(200), default='/static/images/default-avatar.png')
    provider = db.Column(db.String(20), default='local')  # 'local', 'google', 'facebook'

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

class Movie(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    genre = db.Column(db.String(50), nullable=False)
    duration = db.Column(db.Integer, nullable=False)  # in minutes
    description = db.Column(db.Text)
    poster_url = db.Column(db.String(200))
    trailer_url = db.Column(db.String(200))
    language = db.Column(db.String(50), default='English')
    rating = db.Column(db.Float, default=0.0)
    is_active = db.Column(db.Boolean, default=True)
    director = db.Column(db.String(100))
    cast = db.Column(db.Text)  # JSON string of cast members

class Showtime(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    movie_id = db.Column(db.Integer, db.ForeignKey('movie.id'), nullable=False)
    time = db.Column(db.DateTime, nullable=False)
    hall = db.Column(db.String(50), nullable=False)
    rows = db.Column(db.Integer, nullable=False)
    cols = db.Column(db.Integer, nullable=False)
    seat_categories = db.Column(db.Text)  # JSON string of seat categories
    price_standard = db.Column(db.Float, default=10.0)
    price_premium = db.Column(db.Float, default=15.0)
    price_vip = db.Column(db.Float, default=20.0)
    
    movie = db.relationship('Movie', backref=db.backref('showtimes', lazy=True))

class SeatLayout(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    showtime_id = db.Column(db.Integer, db.ForeignKey('showtime.id'), unique=True, nullable=False)
    layout = db.Column(db.Text, nullable=False)  # JSON string of seat layout
    
    showtime = db.relationship('Showtime', backref=db.backref('seat_layout', uselist=False))

class Booking(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    showtime_id = db.Column(db.Integer, db.ForeignKey('showtime.id'), nullable=False)
    seats = db.Column(db.Text, nullable=False)  # JSON string of booked seats
    total_price = db.Column(db.Float, nullable=False)
    booking_time = db.Column(db.DateTime, default=datetime.utcnow)
    status = db.Column(db.String(20), default='confirmed')  # confirmed, cancelled, refunded
    payment_intent_id = db.Column(db.String(100))  # Stripe payment intent ID
    
    user = db.relationship('User', backref=db.backref('bookings', lazy=True))
    showtime = db.relationship('Showtime', backref=db.backref('bookings', lazy=True))

class Review(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    movie_id = db.Column(db.Integer, db.ForeignKey('movie.id'), nullable=False)
    rating = db.Column(db.Integer, nullable=False)  # 1-5 stars
    comment = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    user = db.relationship('User', backref=db.backref('reviews', lazy=True))
    movie = db.relationship('Movie', backref=db.backref('reviews', lazy=True))

# ============================================================
# HELPER FUNCTIONS (UPDATED)
# ============================================================

def create_seat_layout(rows, cols, seat_categories=None):
    """
    Create a seat layout with categories
    Seat codes:
    0: Standard Available, 1: Standard Booked
    2: Premium Available, 3: Premium Booked
    4: VIP Available, 5: VIP Booked
    """
    layout = np.zeros((rows, cols), dtype=int).tolist()
    
    if seat_categories:
        for cat, positions in seat_categories.items():
            for r, c in positions:
                if 0 <= r < rows and 0 <= c < cols:
                    if cat == "premium":
                        layout[r][c] = 2
                    elif cat == "vip":
                        layout[r][c] = 4
    return layout

def get_seat_type(seat_code):
    """Get seat type from seat code"""
    if seat_code in [0, 1]:
        return "Standard"
    elif seat_code in [2, 3]:
        return "Premium"
    elif seat_code in [4, 5]:
        return "VIP"
    return "Standard"

def get_seat_price(showtime, seat_type):
    """Get price for a seat type"""
    if seat_type == "Standard":
        return showtime.price_standard
    elif seat_type == "Premium":
        return showtime.price_premium
    elif seat_type == "VIP":
        return showtime.price_vip
    return showtime.price_standard

def send_email(to_email, subject, body):
    """Send email using SMTP"""
    try:
        msg = MIMEMultipart()
        msg['From'] = app.config['MAIL_USERNAME']
        msg['To'] = to_email
        msg['Subject'] = subject
        
        msg.attach(MIMEText(body, 'html'))
        
        server = smtplib.SMTP(app.config['MAIL_SERVER'], app.config['MAIL_PORT'])
        server.starttls()
        server.login(app.config['MAIL_USERNAME'], app.config['MAIL_PASSWORD'])
        text = msg.as_string()
        server.sendmail(app.config['MAIL_USERNAME'], to_email, text)
        server.quit()
        return True
    except Exception as e:
        print(f"Email error: {str(e)}")
        return False

def generate_qr_code(data):
    """Generate QR code image from data"""
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_L,
        box_size=10,
        border=4,
    )
    qr.add_data(data)
    qr.make(fit=True)
    
    img = qr.make_image(fill_color="black", back_color="white")
    img_io = BytesIO()
    img.save(img_io, 'PNG')
    img_io.seek(0)
    return img_io

def admin_required(f):
    """Decorator to require admin role"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user' not in session or session['user'].get('role') != 'admin':
            flash('Admin access required', 'error')
            return redirect(url_for('index'))
        return f(*args, **kwargs)
    return decorated_function

# Custom template filter
@app.template_filter('fromjson')
def from_json_filter(value):
    return json.loads(value)

@app.template_filter('times')
def times_filter(n):
    return range(n)

# ============================================================
# ROUTES (UPDATED WITH ALL FEATURES)
# ============================================================

@app.route('/')
def index():
    movies = Movie.query.filter_by(is_active=True).all()
    now_showing = movies[:4]  # First 4 movies
    coming_soon = movies[4:] if len(movies) > 4 else []  # Rest as coming soon
    
    # Get featured showtimes for today and tomorrow
    today = datetime.now().date()
    tomorrow = today + timedelta(days=1)
    
    today_showtimes = Showtime.query.filter(
        db.func.date(Showtime.time) == today
    ).join(Movie).filter(Movie.is_active == True).all()
    
    tomorrow_showtimes = Showtime.query.filter(
        db.func.date(Showtime.time) == tomorrow
    ).join(Movie).filter(Movie.is_active == True).all()
    
    return render_template('index.html', 
                         now_showing=now_showing,
                         coming_soon=coming_soon,
                         today_showtimes=today_showtimes,
                         tomorrow_showtimes=tomorrow_showtimes,
                         user=session.get('user'))

@app.route('/movies')
def movies():
    genre = request.args.get('genre')
    search = request.args.get('search')
    
    query = Movie.query.filter_by(is_active=True)
    
    if genre and genre != 'all':
        query = query.filter(Movie.genre.ilike(f'%{genre}%'))
    
    if search:
        query = query.filter(Movie.title.ilike(f'%{search}%'))
    
    all_movies = query.all()
    genres = db.session.query(Movie.genre).distinct().all()
    genres = [g[0] for g in genres]
    
    return render_template('movies.html', 
                         movies=all_movies, 
                         genres=genres,
                         selected_genre=genre or 'all',
                         search_query=search or '',
                         user=session.get('user'))

@app.route('/movie/<int:movie_id>')
def movie_detail(movie_id):
    movie = Movie.query.get_or_404(movie_id)
    
    # Get showtimes for the next 7 days
    start_date = datetime.now().date()
    end_date = start_date + timedelta(days=7)
    
    showtimes = Showtime.query.filter(
        Showtime.movie_id == movie_id,
        Showtime.time >= start_date,
        Showtime.time <= end_date
    ).order_by(Showtime.time).all()
    
    # Group showtimes by date
    showtimes_by_date = {}
    for st in showtimes:
        date_str = st.time.strftime('%Y-%m-%d')
        if date_str not in showtimes_by_date:
            showtimes_by_date[date_str] = []
        showtimes_by_date[date_str].append(st)
    
    # Get reviews with user info
    reviews = Review.query.filter_by(movie_id=movie_id).join(User).order_by(Review.created_at.desc()).all()
    
    # Calculate average rating
    avg_rating = db.session.query(db.func.avg(Review.rating)).filter_by(movie_id=movie_id).scalar() or 0
    
    # Check if user has reviewed this movie
    user_review = None
    if 'user_id' in session:
        user_review = Review.query.filter_by(movie_id=movie_id, user_id=session['user_id']).first()
    
    return render_template('movie_detail.html', 
                         movie=movie, 
                         showtimes_by_date=showtimes_by_date,
                         reviews=reviews,
                         avg_rating=round(avg_rating, 1),
                         user_review=user_review,
                         user=session.get('user'))

@app.route('/showtime/<int:showtime_id>')
def showtime_detail(showtime_id):
    if 'user_id' not in session:
        flash('Please login to book tickets', 'error')
        return redirect(url_for('login'))
    
    showtime = Showtime.query.get_or_404(showtime_id)
    movie = Movie.query.get(showtime.movie_id)
    
    # Get or create seat layout
    seat_layout = SeatLayout.query.filter_by(showtime_id=showtime_id).first()
    if not seat_layout:
        # Create initial seat layout
        categories = json.loads(showtime.seat_categories) if showtime.seat_categories else {}
        layout = create_seat_layout(showtime.rows, showtime.cols, categories)
        
        seat_layout = SeatLayout(showtime_id=showtime_id, layout=json.dumps(layout))
        db.session.add(seat_layout)
        db.session.commit()
    else:
        layout = json.loads(seat_layout.layout)
    
    return render_template('showtime.html', 
                         showtime=showtime, 
                         movie=movie, 
                         layout=layout,
                         user=session.get('user'),
                         stripe_public_key=app.config['STRIPE_PUBLIC_KEY'])

@app.route('/create-payment-intent', methods=['POST'])
def create_payment_intent():
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated'}), 403

    try:
        data = request.get_json()
        amount = int(float(data['amount']) * 100)  # Convert to cents

        intent = stripe.PaymentIntent.create(
            amount=amount,
            currency=data.get('currency', 'usd'),
            metadata={
                'user_id': session['user_id'],
                'showtime_id': data.get('showtime_id', ''),
                'seats': data.get('seats', '')
            }
        )

        return jsonify({'clientSecret': intent.client_secret})
    except Exception as e:
        return jsonify(error=str(e)), 403

@app.route('/confirm-booking', methods=['POST'])
def confirm_booking():
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Please login first'})
    
    try:
        data = request.get_json()
        payment_intent_id = data['payment_intent_id']
        
        # Retrieve payment intent to verify
        intent = stripe.PaymentIntent.retrieve(payment_intent_id)
        
        if intent.status != 'succeeded':
            return jsonify({'success': False, 'message': 'Payment not completed'})
        
        # Extract booking details from metadata
        showtime_id = int(intent.metadata['showtime_id'])
        seats = json.loads(intent.metadata['seats'])
        
        showtime = Showtime.query.get_or_404(showtime_id)
        seat_layout = SeatLayout.query.filter_by(showtime_id=showtime_id).first()
        
        if not seat_layout:
            return jsonify({'success': False, 'message': 'Seat layout not found'})
        
        layout = json.loads(seat_layout.layout)
        total_price = 0
        booking_seats = []
        
        # Check if seats are available and calculate price
        for seat in seats:
            row, col = seat['row'], seat['col']
            if layout[row][col] % 2 == 1:  # Already booked
                return jsonify({'success': False, 'message': f'Seat ({row+1}, {col+1}) is already booked'})
            
            seat_type = get_seat_type(layout[row][col])
            price = get_seat_price(showtime, seat_type)
            total_price += price
            
            booking_seats.append({
                'row': row,
                'col': col,
                'type': seat_type,
                'price': price
            })
        
        # Mark seats as booked
        for seat in seats:
            row, col = seat['row'], seat['col']
            layout[row][col] += 1  # Mark as booked
        
        # Update seat layout
        seat_layout.layout = json.dumps(layout)
        
        # Create booking
        booking = Booking(
            user_id=session['user_id'],
            showtime_id=showtime_id,
            seats=json.dumps(booking_seats),
            total_price=total_price,
            payment_intent_id=payment_intent_id
        )
        
        db.session.add(booking)
        db.session.commit()
        
        # Send confirmation email
        user = User.query.get(session['user_id'])
        movie = Movie.query.get(showtime.movie_id)
        
        email_body = render_template('email/booking_confirmation.html', 
                                   user=user, 
                                   booking=booking, 
                                   movie=movie, 
                                   showtime=showtime)
        
        send_email(user.email, f'Booking Confirmation for {movie.title}', email_body)
        
        return jsonify({
            'success': True, 
            'message': 'Booking successful!', 
            'booking_id': booking.id,
            'total_price': total_price
        })
        
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})

@app.route('/booking-confirmation/<int:booking_id>')
def booking_confirmation(booking_id):
    booking = Booking.query.get_or_404(booking_id)
    
    # Check if user owns this booking
    if 'user_id' not in session or booking.user_id != session['user_id']:
        flash('You are not authorized to view this booking', 'error')
        return redirect(url_for('index'))
    
    return render_template('booking_confirmation.html', 
                         booking=booking,
                         user=session.get('user'))

@app.route('/booking/<int:booking_id>/cancel')
def cancel_booking(booking_id):
    if 'user_id' not in session:
        flash('Please login to cancel bookings', 'error')
        return redirect(url_for('login'))
    
    booking = Booking.query.get_or_404(booking_id)
    
    # Check if user owns this booking
    if booking.user_id != session['user_id']:
        flash('You are not authorized to cancel this booking', 'error')
        return redirect(url_for('my_bookings'))
    
    # Check if cancellation is allowed (at least 2 hours before showtime)
    if booking.showtime.time < datetime.now() + timedelta(hours=2):
        flash('Cancellation is only allowed at least 2 hours before showtime', 'error')
        return redirect(url_for('my_bookings'))
    
    # Process refund via Stripe
    try:
        if booking.payment_intent_id:
            refund = stripe.Refund.create(
                payment_intent=booking.payment_intent_id
            )
            
            if refund.status == 'succeeded':
                booking.status = 'refunded'
                
                # Free up the seats
                seat_layout = SeatLayout.query.filter_by(showtime_id=booking.showtime_id).first()
                if seat_layout:
                    layout = json.loads(seat_layout.layout)
                    seats = json.loads(booking.seats)
                    
                    for seat in seats:
                        row, col = seat['row'], seat['col']
                        layout[row][col] -= 1  # Mark as available
                    
                    seat_layout.layout = json.dumps(layout)
                
                db.session.commit()
                
                # Send cancellation email
                user = User.query.get(session['user_id'])
                movie = Movie.query.get(booking.showtime.movie_id)
                
                email_body = render_template('email/booking_cancellation.html', 
                                           user=user, 
                                           booking=booking, 
                                           movie=movie, 
                                           showtime=booking.showtime)
                
                send_email(user.email, f'Booking Cancellation for {movie.title}', email_body)
                
                flash('Booking cancelled and refund processed successfully', 'success')
            else:
                flash('Refund processing failed', 'error')
        else:
            booking.status = 'cancelled'
            db.session.commit()
            flash('Booking cancelled successfully', 'success')
    except Exception as e:
        flash(f'Error processing cancellation: {str(e)}', 'error')
    
    return redirect(url_for('my_bookings'))

@app.route('/booking/<int:booking_id>/qrcode')
def booking_qrcode(booking_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    booking = Booking.query.get_or_404(booking_id)
    
    # Check if user owns this booking
    if booking.user_id != session['user_id']:
        flash('You are not authorized to view this QR code', 'error')
        return redirect(url_for('my_bookings'))
    
    # Generate QR code with booking details
    qr_data = {
        'booking_id': booking.id,
        'movie': booking.showtime.movie.title,
        'showtime': booking.showtime.time.isoformat(),
        'hall': booking.showtime.hall,
        'seats': json.loads(booking.seats)
    }
    
    qr_img = generate_qr_code(json.dumps(qr_data))
    return send_file(qr_img, mimetype='image/png')

@app.route('/my-bookings')
def my_bookings():
    if 'user_id' not in session:
        flash('Please login to view your bookings', 'error')
        return redirect(url_for('login'))
    
    bookings = Booking.query.filter_by(user_id=session['user_id']).order_by(Booking.booking_time.desc()).all()
    return render_template('my_bookings.html', 
                         bookings=bookings,
                         user=session.get('user'))

@app.route('/movie/<int:movie_id>/review', methods=['POST'])
def add_review(movie_id):
    if 'user_id' not in session:
        flash('Please login to submit a review', 'error')
        return redirect(url_for('login'))
    
    movie = Movie.query.get_or_404(movie_id)
    rating = request.form.get('rating')
    comment = request.form.get('comment')
    
    # Check if user has already reviewed this movie
    existing_review = Review.query.filter_by(movie_id=movie_id, user_id=session['user_id']).first()
    
    if existing_review:
        existing_review.rating = rating
        existing_review.comment = comment
        flash('Review updated successfully', 'success')
    else:
        review = Review(
            user_id=session['user_id'],
            movie_id=movie_id,
            rating=rating,
            comment=comment
        )
        db.session.add(review)
        flash('Review submitted successfully', 'success')
    
    db.session.commit()
    return redirect(url_for('movie_detail', movie_id=movie_id))

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        email = request.form['email']
        full_name = request.form.get('full_name', '')
        phone = request.form.get('phone', '')
        
        # Check if user exists
        if User.query.filter_by(username=username).first():
            flash('Username already exists', 'error')
            return redirect(url_for('register'))
        
        if User.query.filter_by(email=email).first():
            flash('Email already registered', 'error')
            return redirect(url_for('register'))
        
        # Create new user
        user = User(username=username, email=email, full_name=full_name, phone=phone)
        user.set_password(password)
        db.session.add(user)
        db.session.commit()
        
        flash('Registration successful! Please login.', 'success')
        return redirect(url_for('login'))
    
    return render_template('register.html', user=session.get('user'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        user = User.query.filter_by(username=username).first()
        
        if user and user.check_password(password):
            session['user_id'] = user.id
            session['user'] = {
                'id': user.id,
                'username': user.username,
                'email': user.email,
                'full_name': user.full_name,
                'role': user.role,
                'avatar': user.avatar
            }
            flash('Login successful!', 'success')
            return redirect(url_for('index'))
        else:
            flash('Invalid username or password', 'error')
    
    return render_template('login.html', user=session.get('user'))

@app.route('/login/google')
def login_google():
    redirect_uri = url_for('authorize_google', _external=True)
    return google.authorize_redirect(redirect_uri)

@app.route('/login/google/authorize')
def authorize_google():
    try:
        token = google.authorize_access_token()
        user_info = google.get('userinfo').json()
        
        # Check if user exists by email
        user = User.query.filter_by(email=user_info['email']).first()
        
        if not user:
            # Create new user
            user = User(
                username=user_info['email'].split('@')[0],
                email=user_info['email'],
                full_name=user_info.get('name', ''),
                avatar=user_info.get('picture', '/static/images/default-avatar.png'),
                provider='google'
            )
            db.session.add(user)
            db.session.commit()
        
        session['user_id'] = user.id
        session['user'] = {
            'id': user.id,
            'username': user.username,
            'email': user.email,
            'full_name': user.full_name,
            'role': user.role,
            'avatar': user.avatar
        }
        
        flash('Login successful!', 'success')
        return redirect(url_for('index'))
    
    except Exception as e:
        flash('Google login failed', 'error')
        return redirect(url_for('login'))

@app.route('/logout')
def logout():
    session.pop('user_id', None)
    session.pop('user', None)
    flash('You have been logged out', 'info')
    return redirect(url_for('index'))

# ============================================================
# ADMIN ROUTES
# ============================================================

@app.route('/admin')
@admin_required
def admin_dashboard():
    # Get stats for dashboard
    total_movies = Movie.query.count()
    total_bookings = Booking.query.count()
    total_users = User.query.count()
    total_revenue = db.session.query(db.func.sum(Booking.total_price)).filter(Booking.status == 'confirmed').scalar() or 0
    
    # Recent bookings
    recent_bookings = Booking.query.order_by(Booking.booking_time.desc()).limit(10).all()
    
    return render_template('admin/dashboard.html',
                         total_movies=total_movies,
                         total_bookings=total_bookings,
                         total_users=total_users,
                         total_revenue=total_revenue,
                         recent_bookings=recent_bookings,
                         user=session.get('user'))

@app.route('/admin/movies')
@admin_required
def admin_movies():
    movies = Movie.query.all()
    return render_template('admin/movies.html', movies=movies, user=session.get('user'))

@app.route('/admin/movies/add', methods=['GET', 'POST'])
@admin_required
def admin_add_movie():
    if request.method == 'POST':
        title = request.form['title']
        genre = request.form['genre']
        duration = request.form['duration']
        description = request.form['description']
        language = request.form['language']
        rating = request.form['rating']
        director = request.form['director']
        cast = request.form['cast']
        trailer_url = request.form['trailer_url']
        
        # Handle file upload
        poster = request.files['poster']
        poster_url = ''
        
        if poster and poster.filename:
            filename = secure_filename(poster.filename)
            poster_path = os.path.join(app.config['UPLOAD_FOLDER'], 'posters', filename)
            os.makedirs(os.path.dirname(poster_path), exist_ok=True)
            poster.save(poster_path)
            poster_url = f"/static/uploads/posters/{filename}"
        
        movie = Movie(
            title=title,
            genre=genre,
            duration=duration,
            description=description,
            poster_url=poster_url,
            trailer_url=trailer_url,
            language=language,
            rating=rating,
            director=director,
            cast=cast
        )
        
        db.session.add(movie)
        db.session.commit()
        
        flash('Movie added successfully', 'success')
        return redirect(url_for('admin_movies'))
    
    return render_template('admin/add_movie.html', user=session.get('user'))

@app.route('/admin/showtimes')
@admin_required
def admin_showtimes():
    showtimes = Showtime.query.order_by(Showtime.time.desc()).all()
    return render_template('admin/showtimes.html', showtimes=showtimes, user=session.get('user'))

@app.route('/admin/showtimes/add', methods=['GET', 'POST'])
@admin_required
def admin_add_showtime():
    if request.method == 'POST':
        movie_id = request.form['movie_id']
        time_str = request.form['time']
        hall = request.form['hall']
        rows = request.form['rows']
        cols = request.form['cols']
        price_standard = request.form['price_standard']
        price_premium = request.form['price_premium']
        price_vip = request.form['price_vip']
        
        # Parse datetime
        time = datetime.strptime(time_str, '%Y-%m-%dT%H:%M')
        
        showtime = Showtime(
            movie_id=movie_id,
            time=time,
            hall=hall,
            rows=rows,
            cols=cols,
            price_standard=price_standard,
            price_premium=price_premium,
            price_vip=price_vip
        )
        
        db.session.add(showtime)
        db.session.commit()
        
        flash('Showtime added successfully', 'success')
        return redirect(url_for('admin_showtimes'))
    
    movies = Movie.query.all()
    return render_template('admin/add_showtime.html', movies=movies, user=session.get('user'))

@app.route('/admin/bookings')
@admin_required
def admin_bookings():
    bookings = Booking.query.order_by(Booking.booking_time.desc()).all()
    return render_template('admin/bookings.html', bookings=bookings, user=session.get('user'))

@app.route('/admin/users')
@admin_required
def admin_users():
    users = User.query.all()
    return render_template('admin/users.html', users=users, user=session.get('user'))

# ============================================================
# INITIAL DATA SETUP
# ============================================================

def init_db():
    """Initialize database with sample data"""
    db.create_all()
    
    # Create admin user if not exists
    if not User.query.filter_by(username='admin').first():
        admin = User(username='admin', email='admin@cinema.com', full_name='Admin User', role='admin')
        admin.set_password('admin123')
        db.session.add(admin)
    
    # Add sample movies if none exist
    if not Movie.query.first():
        movies = [
            Movie(
                title='Avatar: The Way of Water',
                genre='Sci-Fi',
                duration=192,
                description='Jake Sully lives with his newfound family formed on the planet of Pandora. Once a familiar threat returns to finish what was previously started, Jake must work with Neytiri and the army of the Na\'vi race to protect their planet.',
                poster_url='/static/images/avatar.jpg',
                trailer_url='https://www.youtube.com/embed/d9MyW72ELq0',
                language='English',
                rating=8.2,
                director='James Cameron',
                cast='["Sam Worthington", "Zoe Saldana", "Sigourney Weaver"]'
            ),
            Movie(
                title='John Wick: Chapter 4',
                genre='Action',
                duration=169,
                description='John Wick uncovers a path to defeating The High Table. But before he can earn his freedom, Wick must face off against a new enemy with powerful alliances across the globe and forces that turn old friends into foes.',
                poster_url='/static/images/johnwick.jpg',
                trailer_url='https://www.youtube.com/embed/qEVUtrk8_B4',
                language='English',
                rating=8.5,
                director='Chad Stahelski',
                cast='["Keanu Reeves", "Donnie Yen", "Bill Skarsgård"]'
            ),
            Movie(
                title='The Super Mario Bros. Movie',
                genre='Animation',
                duration=92,
                description='A plumber named Mario travels through an underground labyrinth with his brother, Luigi, trying to save a captured princess.',
                poster_url='/static/images/mario.jpg',
                trailer_url='https://www.youtube.com/embed/TnGl01FkMMo',
                language='English',
                rating=7.5,
                director='Michael Jelenic, Aaron Horvath',
                cast='["Chris Pratt", "Anya Taylor-Joy", "Charlie Day"]'
            ),
            Movie(
                title='Oppenheimer',
                genre='Biography',
                duration=180,
                description='The story of American scientist J. Robert Oppenheimer and his role in the development of the atomic bomb.',
                poster_url='/static/images/oppenheimer.jpg',
                trailer_url='https://www.youtube.com/embed/uYPbbksJxIg',
                language='English',
                rating=8.8,
                director='Christopher Nolan',
                cast='["Cillian Murphy", "Emily Blunt", "Matt Damon"]'
            ),
            Movie(
                title='Fast X',
                genre='Action',
                duration=141,
                description='Dom Toretto and his family are targeted by the vengeful son of drug kingpin Hernan Reyes.',
                poster_url='/static/images/fastx.jpg',
                trailer_url='https://www.youtube.com/embed/32RAq6JzY-w',
                language='English',
                rating=6.9,
                director='Louis Leterrier',
                cast='["Vin Diesel", "Michelle Rodriguez", "Jason Momoa"]'
            ),
            Movie(
                title='The Little Mermaid',
                genre='Fantasy',
                duration=135,
                description='A young mermaid makes a deal with a sea witch to trade her beautiful voice for human legs so she can discover the world above water and impress a prince.',
                poster_url='/static/images/mermaid.jpg',
                trailer_url='https://www.youtube.com/embed/kpGo2_d3oYE',
                language='English',
                rating=7.5,
                director='Rob Marshall',
                cast='["Halle Bailey", "Jonah Hauer-King", "Melissa McCarthy"]'
            )
        ]
        db.session.add_all(movies)
        db.session.commit()
    
    # Add sample showtimes if none exist
    if not Showtime.query.first():
        movie1 = Movie.query.filter_by(title='Avatar: The Way of Water').first()
        movie2 = Movie.query.filter_by(title='John Wick: Chapter 4').first()
        
        if movie1 and movie2:
            # Create showtimes for the next 7 days
            now = datetime.now()
            showtimes = []
            
            for i in range(7):
                date = now + timedelta(days=i)
                
                # Avatar showtimes
                showtimes.append(Showtime(
                    movie_id=movie1.id,
                    time=datetime(date.year, date.month, date.day, 10, 0),
                    hall='Hall 1',
                    rows=8,
                    cols=10,
                    seat_categories=json.dumps({
                        "premium": [(0,0), (0,1), (0,8), (0,9)],
                        "vip": [(3,4), (3,5), (4,4), (4,5)]
                    }),
                    price_standard=12.0,
                    price_premium=18.0,
                    price_vip=25.0
                ))
                
                showtimes.append(Showtime(
                    movie_id=movie1.id,
                    time=datetime(date.year, date.month, date.day, 16, 30),
                    hall='Hall 2',
                    rows=8,
                    cols=10,
                    seat_categories=json.dumps({
                        "premium": [(0,0), (0,1), (0,8), (0,9)],
                        "vip": [(3,4), (3,5), (4,4), (4,5)]
                    }),
                    price_standard=12.0,
                    price_premium=18.0,
                    price_vip=25.0
                ))
                
                # John Wick showtimes
                showtimes.append(Showtime(
                    movie_id=movie2.id,
                    time=datetime(date.year, date.month, date.day, 13, 15),
                    hall='Hall 3',
                    rows=8,
                    cols=10,
                    seat_categories=json.dumps({
                        "premium": [(0,0), (0,1), (0,8), (0,9)],
                        "vip": [(3,4), (3,5), (4,4), (4,5)]
                    }),
                    price_standard=11.0,
                    price_premium=16.0,
                    price_vip=22.0
                ))
                
                showtimes.append(Showtime(
                    movie_id=movie2.id,
                    time=datetime(date.year, date.month, date.day, 19, 45),
                    hall='Hall 1',
                    rows=8,
                    cols=10,
                    seat_categories=json.dumps({
                        "premium": [(0,0), (0,1), (0,8), (0,9)],
                        "vip": [(3,4), (3,5), (4,4), (4,5)]
                    }),
                    price_standard=11.0,
                    price_premium=16.0,
                    price_vip=22.0
                ))
            
            db.session.add_all(showtimes)
    
    db.session.commit()

# ============================================================
# RUN APPLICATION
# ============================================================

if __name__ == '__main__':
    with app.app_context():
        init_db()
    app.run(debug=True)