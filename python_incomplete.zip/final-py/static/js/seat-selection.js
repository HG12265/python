document.addEventListener('DOMContentLoaded', function() {
    console.log('✅ Seat selection script loaded');

    // Initialize Stripe
    const stripe = Stripe(stripePublicKey);
    const elements = stripe.elements();
    const card = elements.create('card');
    card.mount('#card-element');

    card.on('change', function(event) {
        const displayError = document.getElementById('card-errors');
        if (event.error) {
            displayError.textContent = event.error.message;
        } else {
            displayError.textContent = '';
        }
    });

    const seats = document.querySelectorAll('.seat');
    const selectedSeats = [];
    const bookingForm = document.getElementById('booking-form');
    const submitButton = bookingForm.querySelector('button[type="submit"]');
    let clientSecret = null;

    seats.forEach(seat => {
        if (!seat.classList.contains('booked')) {
            seat.addEventListener('click', function() {
                const row = this.dataset.row;
                const col = this.dataset.col;
                const seatId = `${row},${col}`;

                if (this.classList.contains('selected')) {
                    this.classList.remove('selected');
                    const index = selectedSeats.findIndex(s => s.id === seatId);
                    if (index !== -1) selectedSeats.splice(index, 1);
                } else {
                    this.classList.add('selected');
                    let type = 'Standard';
                    if (this.classList.contains('premium')) type = 'Premium';
                    if (this.classList.contains('vip')) type = 'VIP';

                    let price = parseFloat(this.dataset.price) || 10.0;
                    selectedSeats.push({ id: seatId, row: parseInt(row), col: parseInt(col), type, price });
                }

                updateSelectionSummary();
            });
        }
    });

    function updateSelectionSummary() {
        const summary = document.getElementById('selected-seats');
        const priceSummary = document.getElementById('price-summary');
        const seatsInput = bookingForm.querySelector('input[name="seats"]');

        if (selectedSeats.length === 0) {
            summary.innerHTML = '<p class="text-muted">No seats selected</p>';
            priceSummary.innerHTML = `
                <div class="d-flex justify-content-between">
                    <span>Subtotal:</span>
                    <span>₹0.00</span>
                </div>
                <hr>
                <div class="d-flex justify-content-between fw-bold">
                    <span>Total:</span>
                    <span>₹0.00</span>
                </div>
            `;
            submitButton.disabled = true;
            clientSecret = null;
            return;
        }

        let subtotal = selectedSeats.reduce((sum, seat) => sum + seat.price, 0);

        let html = '<h6>Selected Seats:</h6>';
        selectedSeats.forEach(seat => {
            html += `<div class="d-flex justify-content-between mb-1">
                <span>Row ${seat.row + 1}, Seat ${seat.col + 1} (${seat.type})</span>
                <span>₹${seat.price.toFixed(2)}</span>
            </div>`;
        });
        summary.innerHTML = html;

        priceSummary.innerHTML = `
            <div class="d-flex justify-content-between mb-1">
                <span>Subtotal:</span>
                <span>₹${subtotal.toFixed(2)}</span>
            </div>
            <hr>
            <div class="d-flex justify-content-between fw-bold">
                <span>Total:</span>
                <span>₹${subtotal.toFixed(2)}</span>
            </div>
        `;

        seatsInput.value = JSON.stringify(selectedSeats.map(seat => ({ row: seat.row, col: seat.col })));
        submitButton.disabled = false;

        // Create payment intent
        fetch('/create-payment-intent', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                amount: subtotal,
                currency: "usd",
                showtime_id: bookingForm.querySelector('input[name="showtime_id"]').value,
                seats: JSON.stringify(selectedSeats.map(seat => ({ row: seat.row, col: seat.col })))
            })
        })
        .then(res => {
            if (!res.ok) throw new Error(`Payment Intent Failed: ${res.status}`);
            return res.json();
        })
        .then(data => {
            console.log('✅ Payment intent created:', data);
            clientSecret = data.clientSecret;
        })
        .catch(err => {
            console.error('❌ Error creating payment intent:', err);
            alert('Error creating payment intent: ' + err.message);
            submitButton.disabled = true;
        });
    }

    bookingForm.addEventListener('submit', async function(e) {
        e.preventDefault();
        submitButton.disabled = true;
        submitButton.textContent = 'Processing...';

        if (selectedSeats.length === 0) {
            alert('Please select at least one seat');
            submitButton.disabled = false;
            submitButton.textContent = 'Proceed to Payment';
            return;
        }

        if (!clientSecret) {
            alert('Payment intent not created. Please try again.');
            submitButton.disabled = false;
            submitButton.textContent = 'Proceed to Payment';
            return;
        }

        const { paymentIntent, error } = await stripe.confirmCardPayment(clientSecret, {
            payment_method: {
                card: card,
            }
        });

        if (error) {
            const displayError = document.getElementById('card-errors');
            displayError.textContent = error.message;
            alert('Payment failed: ' + error.message);
            submitButton.disabled = false;
            submitButton.textContent = 'Proceed to Payment';
        } else if (paymentIntent && paymentIntent.status === 'succeeded') {
            // Confirm booking on backend
               fetch("/book", {
                    method: "POST",
                    headers: {
                         "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    seats: selectedSeats,
                    cardNumber: cardNumber,
                    expiry: expiry,
                    cvv: cvv
                })
            })

            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    alert('Booking successful!');
                    window.location.href = '/booking-confirmation/' + data.booking_id;
                } else {
                    alert('Booking confirmation failed: ' + data.message);
                    submitButton.disabled = false;
                    submitButton.textContent = 'Proceed to Payment';
                }
            })
            .catch(err => {
                console.error('Error confirming booking:', err);
                alert('An error occurred during booking confirmation.');
                submitButton.disabled = false;
                submitButton.textContent = 'Proceed to Payment';
            });
        }
    });
});