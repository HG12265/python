import os
import re
import json
from io import BytesIO
from datetime import datetime, timedelta, time as dtime

from flask import (
    Flask,
    render_template,
    request,
    redirect,
    url_for,
    session,
    flash,
    jsonify,
    send_file,
)
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash,  check_password_hash
from werkzeug.utils import secure_filename
import numpy as np
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
import qrcode
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
from authlib.integrations.flask_client import OAuth
from functools import wraps
from dotenv import load_dotenv


# Load environment variables from .env (optional)
load_dotenv()

# -----------------------
# APP & CONFIG
# -----------------------
app = Flask(__name__)
app.secret_key = os.getenv("SECRET_KEY", "cinema_booking_secret_key_2023")
app.config["SQLALCHEMY_DATABASE_URI"] = os.getenv("DATABASE_URL", "sqlite:///cinema.db")
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["UPLOAD_FOLDER"] = os.getenv("UPLOAD_FOLDER", "static/uploads")
app.config["MAX_CONTENT_LENGTH"] = 16 * 1024 * 1024  # 16 MB

# Email configuration (use environment variables in production)
app.config["MAIL_SERVER"] = os.getenv("MAIL_SERVER", "smtp.gmail.com")
app.config["MAIL_PORT"] = int(os.getenv("MAIL_PORT", 587))
app.config["MAIL_USE_TLS"] = os.getenv("MAIL_USE_TLS", "True").lower() in ("true", "1", "yes")
app.config["MAIL_USERNAME"] = os.getenv("MAIL_USERNAME", "gowtham114411@gmail.com")
app.config["MAIL_PASSWORD"] = os.getenv("MAIL_PASSWORD", "agvqkaqzxogxuqsh")

# OAuth (Google) configuration
app.config["GOOGLE_CLIENT_ID"] = os.getenv("GOOGLE_CLIENT_ID", "your_google_client_id")
app.config["GOOGLE_CLIENT_SECRET"] = os.getenv("GOOGLE_CLIENT_SECRET", "your_google_client_secret")

# -----------------------
# EXTENSIONS
# -----------------------

db = SQLAlchemy(app)

oauth = OAuth(app)

google = oauth.register(
    name="google",
    client_id="636577333858-3si28hco6o11t7f9ibq5tihcgbfmki8h.apps.googleusercontent.com",
    client_secret="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",
    server_metadata_url="https://accounts.google.com/.well-known/openid-configuration",
    client_kwargs={
        "scope": "openid email profile"
    }
)



# -----------------------
# DATABASE MODELS
# -----------------------

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=True)  # Nullable for social login
    email = db.Column(db.String(120), unique=True, nullable=False)
    full_name = db.Column(db.String(100))
    phone = db.Column(db.String(15)) 
    role = db.Column(db.String(20), default="user")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    avatar = db.Column(db.String(200), default="/static/images/default-avatar.png")
    provider = db.Column(db.String(20), default="local")  # 'local', 'google', ...

    def set_password(self, password: str):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password: str) -> bool:
        if not self.password_hash:
            return False
        return check_password_hash(self.password_hash, password)


class Movie(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    genre = db.Column(db.String(50), nullable=False)
    duration = db.Column(db.Integer, nullable=False)  # in minutes
    description = db.Column(db.Text)
    poster_url = db.Column(db.String(200))
    trailer_url = db.Column(db.String(200))
    language = db.Column(db.String(50), default="English")
    rating = db.Column(db.Float, default=0.0)
    is_active = db.Column(db.Boolean, default=True)
    director = db.Column(db.String(100))
    cast = db.Column(db.Text)  # JSON string or plain text


class Showtime(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    movie_id = db.Column(db.Integer, db.ForeignKey("movie.id"), nullable=False)
    time = db.Column(db.DateTime, nullable=False)
    hall = db.Column(db.String(50), nullable=False)
    rows = db.Column(db.Integer, nullable=False)
    cols = db.Column(db.Integer, nullable=False)
    seat_categories = db.Column(db.Text)  # JSON string of seat categories
    price_standard = db.Column(db.Float, default=100.0)
    price_premium = db.Column(db.Float, default=150.0)
    price_vip = db.Column(db.Float, default=200.0)

    movie = db.relationship("Movie", backref=db.backref("showtimes", lazy=True))


class SeatLayout(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    showtime_id = db.Column(db.Integer, db.ForeignKey("showtime.id"), unique=True, nullable=False)
    layout = db.Column(db.Text, nullable=False)  # JSON string of seat layout

    showtime = db.relationship("Showtime", backref=db.backref("seat_layout", uselist=False))


class Booking(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    showtime_id = db.Column(db.Integer, db.ForeignKey('showtime.id'), nullable=False)
    seats = db.Column(db.Text, nullable=False)  # JSON string of seats booked
    total_price = db.Column(db.Float, nullable=False)
    booking_time = db.Column(db.DateTime, default=datetime.utcnow)
    status = db.Column(db.String(20), default="confirmed")  # confirmed / cancelled
    payment_method = db.Column(db.String(50), default="dummy")  # ✅ Dummy payment method
    
    user = db.relationship('User', backref='bookings', lazy=True)
    showtime = db.relationship('Showtime', backref='bookings', lazy=True)

    def __repr__(self):
        return f"<Booking {self.id} - User {self.user_id} - Showtime {self.showtime_id}>"


class Review(db.Model): 
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    movie_id = db.Column(db.Integer, db.ForeignKey("movie.id"), nullable=False)
    rating = db.Column(db.Integer, nullable=False)  # 1-5 stars
    comment = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    user = db.relationship("User", backref=db.backref("reviews", lazy=True))
    movie = db.relationship("Movie", backref=db.backref("reviews", lazy=True))


# -----------------------
# HELPER FUNCTIONS
# -----------------------

def create_seat_layout(rows: int, cols: int, seat_categories: dict = None):
    """
    Create a seat layout with categories
    Seat codes:
      0: Standard Available, 1: Standard Booked
      2: Premium Available, 3: Premium Booked
      4: VIP Available, 5: VIP Booked
    """
    rows = int(rows)
    cols = int(cols)
    layout = np.zeros((rows, cols), dtype=int).tolist()

    if seat_categories:
        # seat_categories expected as a dict: {"premium": [[r,c], ...], "vip": [[r,c], ...]}
        for cat, positions in seat_categories.items():
            for pos in positions:
                if not isinstance(pos, (list, tuple)) or len(pos) != 2:
                    continue
                r, c = int(pos[0]), int(pos[1])
                if 0 <= r < rows and 0 <= c < cols:
                    if cat.lower() == "premium":
                        layout[r][c] = 2
                    elif cat.lower() == "vip":
                        layout[r][c] = 4
    return layout


def get_seat_type(seat_code: int) -> str:
    """Get seat type from seat code"""
    if seat_code in (0, 1):
        return "Standard"
    if seat_code in (2, 3):
        return "Premium"
    if seat_code in (4, 5):
        return "VIP"
    return "Standard"


def get_seat_price(showtime: Showtime, seat_type: str) -> float:
    """Get price for a seat type"""
    if seat_type == "Standard":
        return float(showtime.price_standard)
    if seat_type == "Premium":
        return float(showtime.price_premium)
    if seat_type == "VIP":
        return float(showtime.price_vip)
    return float(showtime.price_standard)


def generate_ticket_pdf(booking):
    buffer = BytesIO()
    p = canvas.Canvas(buffer, pagesize=letter)
    p.setFont("Helvetica", 14)
    p.drawString(100, 750, "🎬 Movie Ticket")
    p.drawString(100, 720, f"Movie: {booking.movie}")
    p.drawString(100, 700, f"Showtime: {booking.showtime}")
    p.drawString(100, 680, f"Seats: {', '.join(json.loads(booking.seats))}")
    p.drawString(100, 660, f"Booking ID: {booking.id}")
    p.drawString(100, 640, f"Booked At: {booking.booked_at.strftime('%Y-%m-%d %H:%M:%S')}")

    # QR Code
    qr_data = f"BookingID: {booking.id}, Movie: {booking.movie}, Showtime: {booking.showtime}, Seats: {booking.seats}"
    qr_img = qrcode.make(qr_data)
    qr_path = f"qr_{booking.id}.png"
    qr_img.save(qr_path)
    p.drawImage(qr_path, 400, 600, 150, 150)

    p.showPage()
    p.save()
    buffer.seek(0)
    return buffer


def send_booking_email(user_email, booking):
    sender = "yourmail@gmail.com"
    password = "agvqkaqzxogxuqsh"  # Your Gmail App Password

    msg = MIMEMultipart()
    msg["From"] = sender
    msg["To"] = user_email
    msg["Subject"] = "Your Movie Ticket Confirmation"

    body = f"""
    Hello,

    Your booking is confirmed!

    Movie: {booking.movie}
    Showtime: {booking.showtime}
    Seats: {', '.join(json.loads(booking.seats))}
    Booking ID: {booking.id}

    Enjoy your movie! 🎬
    """
    msg.attach(MIMEText(body, "plain"))

    # Attach PDF
    pdf_buffer = generate_ticket_pdf(booking)
    pdf_part = MIMEApplication(pdf_buffer.read(), _subtype="pdf")
    pdf_part.add_header("Content-Disposition", "attachment", filename=f"ticket_{booking.id}.pdf")
    msg.attach(pdf_part)

    with smtplib.SMTP("smtp.gmail.com", 587) as server:
        server.starttls()
        server.login(sender, password)
        server.sendmail(sender, user_email, msg.as_string())


def generate_qr_code(data: str) -> BytesIO:
    """Generate QR code image from data"""
    qr = qrcode.QRCode(version=1, error_correction=qrcode.constants.ERROR_CORRECT_L, box_size=10, border=4)
    qr.add_data(data)
    qr.make(fit=True)
    img = qr.make_image(fill_color="black", back_color="white")
    img_io = BytesIO()
    img.save(img_io, format="PNG")
    img_io.seek(0)
    return img_io


def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        user = session.get("user") or {}
        if not user or user.get("role") != "admin":
            flash("Admin access required", "error")
            return redirect(url_for("index"))
        return f(*args, **kwargs)

    return decorated


# Template filters
@app.template_filter("fromjson")
def from_json_filter(value):
    try:
        return json.loads(value)
    except Exception:
        return value


@app.template_filter("times")
def times_filter(n):
    try:
        return range(int(n))
    except Exception:
        return range(0)


# -----------------------
# ROUTES
# -----------------------

@app.route("/")
def index():
    movies = Movie.query.filter_by(is_active=True).all()
    now_showing = movies[:4]
    coming_soon = movies[4:] if len(movies) > 4 else []

    today = datetime.now().date()
    tomorrow = today + timedelta(days=1)

    today_start = datetime.combine(today, dtime.min)
    today_end = datetime.combine(today, dtime.max)
    tomorrow_start = datetime.combine(tomorrow, dtime.min)
    tomorrow_end = datetime.combine(tomorrow, dtime.max)

    today_showtimes = (
        Showtime.query.filter(Showtime.time >= today_start, Showtime.time <= today_end)
        .join(Movie)
        .filter(Movie.is_active == True)
        .all()
    )

    tomorrow_showtimes = (
        Showtime.query.filter(Showtime.time >= tomorrow_start, Showtime.time <= tomorrow_end)
        .join(Movie)
        .filter(Movie.is_active == True)
        .all()
    )

    return render_template(
        "index.html",
        now_showing=now_showing,
        coming_soon=coming_soon,
        today_showtimes=today_showtimes,
        tomorrow_showtimes=tomorrow_showtimes,
        user=session.get("user"),
    )


@app.route("/movies")
def movies():
    genre = request.args.get("genre")
    search = request.args.get("search")

    query = Movie.query.filter_by(is_active=True)
    if genre and genre.lower() != "all":
        query = query.filter(Movie.genre.ilike(f"%{genre}%"))
    if search:
        query = query.filter(Movie.title.ilike(f"%{search}%"))

    all_movies = query.all()
    genres = [g[0] for g in db.session.query(Movie.genre).distinct().all()]

    return render_template(
        "movies.html",
        movies=all_movies,
        genres=genres,
        selected_genre=genre or "all",
        search_query=search or "",
        user=session.get("user"),
    )


@app.route("/movie/<int:movie_id>")
def movie_detail(movie_id):
    movie = Movie.query.get_or_404(movie_id)

    start_date = datetime.now().date()
    end_date = start_date + timedelta(days=7)
    start_dt = datetime.combine(start_date, dtime.min)
    end_dt = datetime.combine(end_date, dtime.max)

    showtimes = (
        Showtime.query.filter(Showtime.movie_id == movie_id, Showtime.time >= start_dt, Showtime.time <= end_dt)
        .order_by(Showtime.time)
        .all()
    )

    showtimes_by_date = {}
    for st in showtimes:
        date_str = st.time.strftime("%Y-%m-%d")
        showtimes_by_date.setdefault(date_str, []).append(st)

    reviews = Review.query.filter_by(movie_id=movie_id).order_by(Review.created_at.desc()).all()
    avg_rating = db.session.query(db.func.avg(Review.rating)).filter_by(movie_id=movie_id).scalar() or 0

    user_review = None
    if session.get("user_id"):
        user_review = Review.query.filter_by(movie_id=movie_id, user_id=session["user_id"]).first()

    return render_template(
        "movie_detail.html",
        movie=movie,
        showtimes_by_date=showtimes_by_date,
        reviews=reviews,
        avg_rating=round(avg_rating, 1),
        user_review=user_review,
        user=session.get("user"),
    )


@app.route("/showtime/<int:showtime_id>")
def showtime_detail(showtime_id):
    showtime = Showtime.query.get_or_404(showtime_id)

    # Ensure seat layout
    if showtime.seat_layout:
        layout = showtime.seat_layout.layout
    else:
        categories = showtime.seat_categories
        if isinstance(categories, str):
            try:
                categories = json.loads(categories)
            except Exception:
                categories = {}
        layout = create_seat_layout(showtime.rows, showtime.cols, categories)

    # Pass movie also
    return render_template("showtime.html", 
                           showtime=showtime, 
                           layout=layout, 
                           movie=showtime.movie)


@app.route("/process-payment", methods=["POST"])
def process_payment():
    """Dummy payment processing - always succeeds"""
    if "user_id" not in session:
        return jsonify({"success": False, "message": "Please login first"}), 401

    try:
        data = request.get_json(force=True)
        showtime_id = int(data["showtime_id"])
        seats = data.get("seats", [])
        payment_method = data.get("payment_method", "dummy")

        if not isinstance(seats, list) or not seats:
            return jsonify({"success": False, "message": "No seats selected"}), 400

        showtime = Showtime.query.get_or_404(showtime_id)

        seat_layout = SeatLayout.query.filter_by(showtime_id=showtime_id).first()
        if not seat_layout:
            # Initialize seat layout from showtime's seat_categories if missing
            try:
                seat_cats = json.loads(showtime.seat_categories) if showtime.seat_categories else {}
            except Exception:
                seat_cats = {}
            layout = create_seat_layout(showtime.rows, showtime.cols, seat_cats)
            seat_layout = SeatLayout(showtime_id=showtime_id, layout=json.dumps(layout))
            db.session.add(seat_layout)
            db.session.commit()
        else:
            layout = json.loads(seat_layout.layout)

        total_price = 00.0
        booking_seats = []

        # Validate seats and calculate total
        for seat in seats:
            row = int(seat.get("row"))
            col = int(seat.get("col"))
            if row < 0 or col < 0 or row >= len(layout) or col >= len(layout[0]):
                return jsonify({"success": False, "message": f"Seat index out of range: ({row},{col})"}), 400
            if layout[row][col] % 2 == 1:  # Already booked
                return jsonify({"success": False, "message": f"Seat (Row {row+1}, Col {col+1}) is already booked"}), 409

            seat_type = get_seat_type(layout[row][col])
            price = get_seat_price(showtime, seat_type)
            total_price += price
            booking_seats.append({"row": row, "col": col, "type": seat_type, "price": price})

        # Mark seats as booked
        for seat in booking_seats:
            r, c = seat["row"], seat["col"]
            layout[r][c] += 1

        seat_layout.layout = json.dumps(layout)

        booking = Booking(
            user_id=session["user_id"],
            showtime_id=showtime_id,
            seats=json.dumps(booking_seats),
            total_price=total_price,
            payment_method=payment_method,
        )

        db.session.add(booking)
        db.session.commit()

        # Send confirmation email (best-effort)
        user = User.query.get(session["user_id"])
        movie = Movie.query.get(showtime.movie_id)
        try:
            email_body = render_template(
                "email/booking_confirmation.html", user=user, booking=booking, movie=movie, showtime=showtime
            )
            send_email(user.email, f"Booking Confirmation for {movie.title}", email_body)
        except Exception:
            app.logger.exception("Failed to send booking email; continuing")

        return (
            jsonify({"success": True, "message": "Booking successful!", "booking_id": booking.id, "total_price": total_price}),
            200,
        )

    except Exception as exc:
        app.logger.exception("process_payment error: %s", exc)
        return jsonify({"success": False, "message": str(exc)}), 500


@app.route("/booking-confirmation/<int:booking_id>")
def booking_confirmation(booking_id):
    booking = Booking.query.get_or_404(booking_id)
    if "user_id" not in session or booking.user_id != session["user_id"]:
        flash("You are not authorized to view this booking", "error")
        return redirect(url_for("index"))
    return render_template("booking_confirmation.html", booking=booking, user=session.get("user"))


@app.route("/booking/<int:booking_id>/cancel")
def cancel_booking(booking_id):
    if "user_id" not in session:
        flash("Please login to cancel bookings", "error")
        return redirect(url_for("login"))

    booking = Booking.query.get_or_404(booking_id)
    if booking.user_id != session["user_id"]:
        flash("You are not authorized to cancel this booking", "error")
        return redirect(url_for("my_bookings"))

    # Cancellation allowed only if at least 2 hours before showtime
    if booking.showtime.time < datetime.now() + timedelta(hours=2):
        flash("Cancellation is only allowed at least 2 hours before showtime", "error")
        return redirect(url_for("my_bookings"))

    try:
        booking.status = "cancelled"

        seat_layout = SeatLayout.query.filter_by(showtime_id=booking.showtime_id).first()
        if seat_layout:
            layout = json.loads(seat_layout.layout)
            seats = json.loads(booking.seats)
            for seat in seats:
                r, c = int(seat.get("row")), int(seat.get("col"))
                if 0 <= r < len(layout) and 0 <= c < len(layout[0]):
                    # Only decrement if seat appears booked (odd value)
                    if layout[r][c] % 2 == 1:
                        layout[r][c] -= 1
            seat_layout.layout = json.dumps(layout)

        db.session.commit()

        # Send cancellation email (best-effort)
        user = User.query.get(session["user_id"])
        movie = Movie.query.get(booking.showtime.movie_id)
        try:
            email_body = render_template(
                "email/booking_cancellation.html", user=user, booking=booking, movie=movie, showtime=booking.showtime
            )
            send_email(user.email, f"Booking Cancellation for {movie.title}", email_body)
        except Exception:
            app.logger.exception("Failed to send cancellation email; continuing")
 
        flash("Booking cancelled successfully", "success")
    except Exception as exc:
        app.logger.exception("Error processing cancellation: %s", exc)
        flash(f"Error processing cancellation: {exc}", "error")

    return redirect(url_for("my_bookings"))


@app.route("/booking/<int:booking_id>/qrcode")
def booking_qrcode(booking_id):
    if "user_id" not in session:
        return redirect(url_for("login"))

    booking = Booking.query.get_or_404(booking_id)
    if booking.user_id != session["user_id"]:
        flash("You are not authorized to view this QR code", "error")
        return redirect(url_for("my_bookings"))

    qr_data = json.dumps(
        {
            "booking_id": booking.id,
            "movie": booking.showtime.movie.title,
            "showtime": booking.showtime.time.isoformat(),
            "hall": booking.showtime.hall,
            "seats": json.loads(booking.seats),
        }
    )

    qr_img = generate_qr_code(qr_data)
    return send_file(qr_img, mimetype="image/png")


@app.route('/my_bookings')
def my_bookings():
    if "user_id" not in session:
        flash("Please login to view your bookings.", "warning")
        return redirect(url_for('login'))

    user_id = session["user_id"]
    bookings = Booking.query.filter_by(user_id=user_id).all()

    now = datetime.now()
    buffer_time = timedelta(hours=2)

    return render_template("my_bookings.html", bookings=bookings, now=now, buffer_time=buffer_time)



@app.route("/movie/<int:movie_id>/review", methods=["POST"])
def add_review(movie_id):
    if "user_id" not in session:
        flash("Please login to submit a review", "error")
        return redirect(url_for("login"))

    movie = Movie.query.get_or_404(movie_id)
    rating = request.form.get("rating")
    comment = request.form.get("comment")

    try:
        rating_val = int(rating)
    except Exception:
        rating_val = 0

    existing_review = Review.query.filter_by(movie_id=movie_id, user_id=session["user_id"]).first()
    if existing_review:
        existing_review.rating = rating_val
        existing_review.comment = comment
        flash("Review updated successfully", "success")
    else:
        review = Review(user_id=session["user_id"], movie_id=movie_id, rating=rating_val, comment=comment)
        db.session.add(review)
        flash("Review submitted successfully", "success")

    db.session.commit()
    return redirect(url_for("movie_detail", movie_id=movie_id))


@app.route("/booking/success")
def booking_success():
    booking_id = request.args.get("booking_id")
    if not booking_id:
        flash("Invalid booking reference.", "danger")
        return redirect(url_for("index"))

    try:
        booking = Booking.query.get_or_404(int(booking_id))
        if "user_id" not in session or booking.user_id != session["user_id"]:
            flash("You are not authorized to view this booking.", "danger")
            return redirect(url_for("index"))

        flash("Booking confirmed! Your ticket is ready.", "success")
        return redirect(url_for("booking_confirmation", booking_id=booking_id))
    except Exception as exc:
        app.logger.exception("Error confirming booking: %s", exc)
        flash(f"Error confirming booking: {exc}", "danger")
        return redirect(url_for("index"))


def _sanitize_filename(name: str) -> str:
    name = re.sub(r"[^a-zA-Z0-9_\-\.]+", "_", name)
    return name[:200]


@app.route("/download_ticket/<int:booking_id>")
def download_ticket(booking_id):
    try:
        if "user_id" not in session:
            flash("You must be logged in to download tickets.", "danger")
            return redirect(url_for("login"))

        booking = Booking.query.get_or_404(booking_id)
        if booking.user_id != session["user_id"]:
            flash("You are not authorized to download this ticket.", "danger")
            return redirect(url_for("index"))

        showtime = booking.showtime
        movie = showtime.movie

        buffer = BytesIO()
        pdf = canvas.Canvas(buffer, pagesize=A4)
        width, height = A4

        pdf.setTitle("Movie Ticket")
        pdf.setFont("Helvetica-Bold", 20)
        pdf.drawCentredString(width / 2, height - 80, "\U0001F39F Movie Ticket \U0001F39F")

        pdf.setFont("Helvetica-Bold", 14)
        pdf.drawString(100, height - 150, f"Movie: {movie.title}")
        pdf.drawString(100, height - 170, f"Hall: {showtime.hall}")
        pdf.drawString(100, height - 190, f"Showtime: {showtime.time.strftime('%d-%m-%Y %I:%M %p')}")

        pdf.setFont("Helvetica", 12)
        booked_seats = json.loads(booking.seats)
        seat_numbers = [f"Row {s['row']+1}, Col {s['col']+1}" for s in booked_seats]
        pdf.drawString(100, height - 220, "Seats: " + ", ".join(seat_numbers))
        pdf.drawString(100, height - 240, f"Total Price: ${booking.total_price}")

        pdf.setFont("Helvetica-Oblique", 10)
        pdf.drawCentredString(width / 2, 100, "Please arrive 15 minutes early. Enjoy the show!")

        pdf.showPage()
        pdf.save()

        buffer.seek(0)

        safe_title = _sanitize_filename(movie.title)
        return send_file(buffer, as_attachment=True, download_name=f"ticket_{safe_title}_{booking.id}.pdf", mimetype="application/pdf")

    except Exception as exc:
        app.logger.exception("Error generating ticket: %s", exc)
        flash(f"Error generating ticket: {exc}", "danger")
        return redirect(url_for("index"))


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        email = request.form.get("email", "").strip()
        full_name = request.form.get("full_name", "")
        phone = request.form.get("phone", "")

        if not username or not password or not email:
            flash("Username, password and email are required", "error")
            return redirect(url_for("register"))

        if User.query.filter_by(username=username).first():
            flash("Username already exists", "error")
            return redirect(url_for("register"))
        if User.query.filter_by(email=email).first():
            flash("Email already registered", "error")
            return redirect(url_for("register"))

        user = User(username=username, email=email, full_name=full_name, phone=phone)
        user.set_password(password)
        db.session.add(user)
        db.session.commit()

        flash("Registration successful! Please login.", "success")
        return redirect(url_for("login"))

    return render_template("register.html", user=session.get("user"))


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")

        user = User.query.filter_by(username=username).first()
        if user and user.check_password(password):
            session["user_id"] = user.id
            session["user"] = {
                "id": user.id,
                "username": user.username,
                "email": user.email,
                "full_name": user.full_name,
                "role": user.role,
                "avatar": user.avatar,
            }
            flash("Login successful!", "success")
            return redirect(url_for("index"))
        flash("Invalid username or password", "error")

    return render_template("login.html", user=session.get("user"))

@app.route("/login/google")
def login_google():
    redirect_uri = url_for("authorize_google", _external=True)
    return oauth.google.authorize_redirect(redirect_uri)


@app.route("/authorize/google")
def authorize_google():
    try:
        token = oauth.google.authorize_access_token()
        user_info = token.get("userinfo")

        if not user_info:
            # fallback: fetch from endpoint
            user_info = oauth.google.get("userinfo").json()

        if not user_info or "email" not in user_info:
            flash("Google login failed, user info missing.", "error")
            return redirect(url_for("login"))

        # Check or create user
        user = User.query.filter_by(email=user_info["email"]).first()
        if not user:
            username = user_info["email"].split("@")[0]
            user = User(
                username=username,
                email=user_info["email"],
                full_name=user_info.get("name", ""),
                avatar=user_info.get("picture", "/static/images/default-avatar.png"),
                provider="google",
            )
            db.session.add(user)
            db.session.commit()

        session["user_id"] = user.id
        session["user"] = {
            "id": user.id,
            "username": user.username,
            "email": user.email,
            "full_name": user.full_name,
            "role": user.role,
            "avatar": user.avatar,
        }

        flash("Google Login Successful!", "success")
        return redirect(url_for("index"))

    except Exception as exc:
        app.logger.exception("Google login failed: %s", exc)
        flash("Google login failed, please try again.", "error")
        return redirect(url_for("login"))

        
@app.route("/logout")
def logout():
    session.pop("user_id", None)
    session.pop("user", None)
    flash("You have been logged out", "info")
    return redirect(url_for("index"))


# -----------------------
# ADMIN ROUTES
# -----------------------

@app.route("/admin")
@admin_required
def admin_dashboard():
    total_movies = Movie.query.count()
    total_bookings = Booking.query.count()
    total_users = User.query.count()
    total_revenue = db.session.query(db.func.sum(Booking.total_price)).filter(Booking.status == "confirmed").scalar() or 0
    recent_bookings = Booking.query.order_by(Booking.booking_time.desc()).limit(10).all()
    return render_template(
        "admin/dashboard.html",
        total_movies=total_movies,
        total_bookings=total_bookings,
        total_users=total_users,
        total_revenue=total_revenue,
        recent_bookings=recent_bookings,
        user=session.get("user"),
    )


@app.route("/admin/movies")
@admin_required
def admin_movies():
    movies = Movie.query.all()
    return render_template("admin/movies.html", movies=movies, user=session.get("user"))


@app.route("/admin/movies/add", methods=["GET", "POST"])
@admin_required
def admin_add_movie():
    if request.method == "POST":
        title = request.form.get("title", "").strip()
        genre = request.form.get("genre", "").strip()
        duration = int(request.form.get("duration", 0))
        description = request.form.get("description", "")
        language = request.form.get("language", "English")
        try:
            rating = float(request.form.get("rating", 0.0))
        except Exception:
            rating = 0.0
        director = request.form.get("director", "")
        cast = request.form.get("cast", "")
        trailer_url = request.form.get("trailer_url", "")

        poster = request.files.get("poster")
        poster_url = ""
        if poster and poster.filename:
            filename = secure_filename(poster.filename)
            poster_path = os.path.join(app.config["UPLOAD_FOLDER"], "posters", filename)
            os.makedirs(os.path.dirname(poster_path), exist_ok=True)
            poster.save(poster_path)
            poster_url = f"/{poster_path.replace('\\\\', '/') }"

        movie = Movie(
            title=title,
            genre=genre,
            duration=duration,
            description=description,
            poster_url=poster_url,
            trailer_url=trailer_url,
            language=language,
            rating=rating,
            director=director,
            cast=cast,
        )
        db.session.add(movie)
        db.session.commit()
        flash("Movie added successfully", "success")
        return redirect(url_for("admin_movies"))

    return render_template("admin/add_movie.html", user=session.get("user"))


@app.route("/admin/showtimes")
@admin_required
def admin_showtimes():
    showtimes = Showtime.query.order_by(Showtime.time.desc()).all()
    return render_template("admin/showtimes.html", showtimes=showtimes, user=session.get("user"))


@app.route("/admin/showtimes/add", methods=["GET", "POST"])
@admin_required
def admin_add_showtime():
    if request.method == "POST":
        try:
            movie_id = int(request.form.get("movie_id"))
            time_str = request.form.get("time")
            hall = request.form.get("hall", "Hall 1")
            rows = int(request.form.get("rows", 8))
            cols = int(request.form.get("cols", 10))
            price_standard = float(request.form.get("price_standard", 100.0))
            price_premium = float(request.form.get("price_premium", 150.0))
            price_vip = float(request.form.get("price_vip", 200.0))

            # Parse datetime input (expects HTML5 datetime-local format: YYYY-MM-DDTHH:MM)
            time_parsed = datetime.strptime(time_str, "%Y-%m-%dT%H:%M")

            # Seat categories may be provided as JSON in the form. If not, default to empty dict.
            seat_categories_raw = request.form.get("seat_categories", "{}")
            try:
                seat_categories = json.loads(seat_categories_raw)
            except Exception:
                seat_categories = {}

            showtime = Showtime(
                movie_id=movie_id,
                time=time_parsed,
                hall=hall,
                rows=rows,
                cols=cols,
                seat_categories=json.dumps(seat_categories),
                price_standard=price_standard,
                price_premium=price_premium,
                price_vip=price_vip,
            )

            # create seat layout for this showtime
            layout = create_seat_layout(rows, cols, seat_categories)
            seat_layout = SeatLayout(layout=json.dumps(layout))
            showtime.seat_layout = seat_layout

            db.session.add(showtime)
            db.session.commit()
            flash("Showtime added successfully", "success")
            return redirect(url_for("admin_showtimes"))
        except Exception as exc:
            app.logger.exception("Error adding showtime: %s", exc)
            flash(f"Error adding showtime: {exc}", "error")
            return redirect(url_for("admin_add_showtime"))

    movies = Movie.query.all()
    return render_template("admin/add_showtime.html", movies=movies, user=session.get("user"))


@app.route("/admin/bookings")
@admin_required
def admin_bookings():
    bookings = Booking.query.order_by(Booking.booking_time.desc()).all()
    return render_template("admin/bookings.html", bookings=bookings, user=session.get("user"))


@app.route("/admin/users")
@admin_required
def admin_users():
    users = User.query.all()
    return render_template("admin/users.html", users=users, user=session.get("user"))


# -----------------------
# INITIAL DATA SETUP
# -----------------------

def init_db():
    db.create_all()

    if not User.query.filter_by(username="admin").first():
        admin = User(username="admin", email="admin@cinema.com", full_name="Admin User", role="admin")
        admin.set_password("admin123")
        db.session.add(admin)

    if not Movie.query.first():
        def _movie(**kwargs):
            m = Movie(**kwargs)
            db.session.add(m)
            return m

        movie1 = _movie(
            title="Avatar: The Way of Water",
            genre="Sci-Fi",
            duration=192,
            description="Jake Sully lives with his newfound family...",
            poster_url="/static/images/avatar.jpg",
            trailer_url="https://www.youtube.com/embed/d9MyW72ELq0",
            language="English",
            rating=8.2,
            director="James Cameron",
            cast=json.dumps(["Sam Worthington", "Zoe Saldana", "Sigourney Weaver"]),
        )
        movie2 = _movie(
            title="John Wick: Chapter 4",
            genre="Action",
            duration=169,
            description="John Wick uncovers a path to defeating The High Table...",
            poster_url="/static/images/johnwick.jpg",
            trailer_url="https://www.youtube.com/embed/qEVUtrk8_B4",
            language="English",
            rating=8.5,
            director="Chad Stahelski",
            cast=json.dumps(["Keanu Reeves", "Donnie Yen", "Bill Skarsgård"]),
        )
        movie3 = _movie(
            title="The Super Mario Bros. Movie",
            genre="Animation",
            duration=92,
            description="A plumber named Mario travels through...",
            poster_url="/static/images/mario.jpg",
            trailer_url="https://www.youtube.com/embed/TnGl01FkMMo",
            language="English",
            rating=7.5,
            director="Michael Jelenic, Aaron Horvath",
            cast=json.dumps(["Chris Pratt", "Anya Taylor-Joy", "Charlie Day"]),
        )
        movie4 = _movie(
            title="Oppenheimer",
            genre="Biography",
            duration=180,
            description="The story of American scientist J. Robert Oppenheimer...",
            poster_url="/static/images/oppenheimer.jpg",
            trailer_url="https://www.youtube.com/embed/uYPbbksJxIg",
            language="English",
            rating=8.8,
            director="Christopher Nolan",
            cast=json.dumps(["Cillian Murphy", "Emily Blunt", "Matt Damon"]),
        )
        movie5 = _movie(
            title="Fast X",
            genre="Action",
            duration=141,
            description="Dom Toretto and his family are targeted...",
            poster_url="/static/images/fastx.jpg",
            trailer_url="https://www.youtube.com/embed/32RAq6JzY-w",
            language="English",
            rating=6.9,
            director="Louis Leterrier",
            cast=json.dumps(["Vin Diesel", "Michelle Rodriguez", "Jason Momoa"]),
        )
        movie6 = _movie(
            title="The Little Mermaid",
            genre="Fantasy",
            duration=135,
            description="A young mermaid makes a deal with a sea witch...",
            poster_url="/static/images/mermaid.jpg",
            trailer_url="https://www.youtube.com/embed/kpGo2_d3oYE",
            language="English",
            rating=7.5,
            director="Rob Marshall",
            cast=json.dumps(["Halle Bailey", "Jonah Hauer-King", "Melissa McCarthy"]),
        )
        db.session.commit()

    # Add showtimes for existing movies if none exist
    if not Showtime.query.first():
        now = datetime.now()
        seat_template = {"premium": [[0, 0], [0, 1], [0, 8], [0, 9]], "vip": [[3, 4], [3, 5], [4, 4], [4, 5]]}
        movies = Movie.query.limit(3).all()
        showtime_objs = []
        for i in range(7):
            d = now + timedelta(days=i)
            for m in movies:
                # morning
                st1 = Showtime(
                    movie_id=m.id,
                    time=datetime(d.year, d.month, d.day, 10, 0),
                    hall="Hall 1",
                    rows=8,
                    cols=10,
                    seat_categories=json.dumps(seat_template),
                    price_standard=120.0,
                    price_premium=180.0,
                    price_vip=250.0,
                )
                st1.seat_layout = SeatLayout(layout=json.dumps(create_seat_layout(8, 10, seat_template)))
                showtime_objs.append(st1)

                # evening
                st2 = Showtime(
                    movie_id=m.id,
                    time=datetime(d.year, d.month, d.day, 19, 30),
                    hall="Hall 2",
                    rows=8,
                    cols=10,
                    seat_categories=json.dumps(seat_template),
                    price_standard=120.0,
                    price_premium=180.0,
                    price_vip=250.0,
                )
                st2.seat_layout = SeatLayout(layout=json.dumps(create_seat_layout(8, 10, seat_template)))
                showtime_objs.append(st2)

        db.session.add_all(showtime_objs)
        db.session.commit()


# -----------------------
# RUN APPLICATION
# -----------------------

if __name__ == "__main__":
    with app.app_context():
        init_db()
    app.run(debug=True)
