import os
import re
import json
from io import BytesIO
from datetime import datetime, timedelta, time as dtime
from functools import wraps
# --- Third-party Libraries ---
from flask import (
    Flask, render_template, request, redirect, url_for,
    session, flash, jsonify, send_file
)
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
import numpy as np
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib.utils import ImageReader
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
from authlib.integrations.flask_client import OAuth
from dotenv import load_dotenv

# --- Load Environment Variables ---
load_dotenv()

# ==============================================================================
# APP & CONFIGURATION SETUP
# ==============================================================================
app = Flask(__name__)

# Load configuration from environment variables with safe defaults

app.secret_key = os.getenv("SECRET_KEY", "dev-secret-key-change-in-production")
app.config["SQLALCHEMY_DATABASE_URI"] = os.getenv("DATABASE_URL", "sqlite:///cinema.db")
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["UPLOAD_FOLDER"] = os.getenv("UPLOAD_FOLDER", "static/uploads")
app.config["MAX_CONTENT_LENGTH"] = 16 * 1024 * 1024
app.config['ALLOWED_EXTENSIONS'] = {'png', 'jpg', 'jpeg', 'gif'}

# Email configuration
app.config["MAIL_SERVER"] = os.getenv("MAIL_SERVER", "smtp.gmail.com")
app.config["MAIL_PORT"] = int(os.getenv("MAIL_PORT", 587))
app.config["MAIL_USE_TLS"] = os.getenv("MAIL_USE_TLS", "True").lower() in ("true", "1")
app.config["MAIL_USERNAME"] = os.getenv("MAIL_USERNAME")
app.config["MAIL_PASSWORD"] = os.getenv("MAIL_PASSWORD")

# OAuth configuration
app.config["GOOGLE_CLIENT_ID"] = os.getenv("GOOGLE_CLIENT_ID")
app.config["GOOGLE_CLIENT_SECRET"] = os.getenv("GOOGLE_CLIENT_SECRET")

# ==============================================================================
# EXTENSIONS INITIALIZATION
# ==============================================================================
db = SQLAlchemy(app)
oauth = OAuth(app)

google = oauth.register(
    name="google",
    client_id=app.config["GOOGLE_CLIENT_ID"],
    client_secret=app.config["GOOGLE_CLIENT_SECRET"],
    server_metadata_url="https://accounts.google.com/.well-known/openid-configuration",
    client_kwargs={"scope": "openid email profile"}
)

# ==============================================================================
# DATABASE MODELS
# ==============================================================================
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    full_name = db.Column(db.String(100))
    role = db.Column(db.String(20), default="user")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    avatar = db.Column(db.String(200), default="/static/images/default-avatar.png")
    provider = db.Column(db.String(20), default="local")
    def set_password(self, p): self.password_hash = generate_password_hash(p)
    def check_password(self, p): return check_password_hash(self.password_hash, p) if self.password_hash else False

class Movie(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    genre = db.Column(db.String(50), nullable=False)
    duration = db.Column(db.Integer, nullable=False)
    description = db.Column(db.Text)
    poster_url = db.Column(db.String(200))
    is_active = db.Column(db.Boolean, default=True)
    # New fields from admin form
    language = db.Column(db.String(50), default="English")
    rating = db.Column(db.Float, default=0.0)
    director = db.Column(db.String(100))
    cast = db.Column(db.Text) # Storing as JSON string
    trailer_url = db.Column(db.String(200))

class Showtime(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    movie_id = db.Column(db.Integer, db.ForeignKey("movie.id"), nullable=False)
    time = db.Column(db.DateTime, nullable=False)
    hall = db.Column(db.String(50), nullable=False)
    rows = db.Column(db.Integer, nullable=False)
    cols = db.Column(db.Integer, nullable=False)
    price_standard = db.Column(db.Float, default=10.0)
    price_premium = db.Column(db.Float, default=15.0)
    price_vip = db.Column(db.Float, default=20.0)
    movie = db.relationship("Movie", backref=db.backref("showtimes", lazy=True, cascade="all, delete-orphan"))

class SeatLayout(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    showtime_id = db.Column(db.Integer, db.ForeignKey("showtime.id"), unique=True, nullable=False)
    layout = db.Column(db.Text, nullable=False)
    showtime = db.relationship("Showtime", backref=db.backref("seat_layout", uselist=False, cascade="all, delete-orphan"))

class Booking(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    showtime_id = db.Column(db.Integer, db.ForeignKey('showtime.id'), nullable=False)
    seats = db.Column(db.Text, nullable=False)
    total_price = db.Column(db.Float, nullable=False)
    booking_time = db.Column(db.DateTime, default=datetime.utcnow)
    status = db.Column(db.String(20), default="confirmed")
    attended = db.Column(db.Boolean, default=False) # New column
    user = db.relationship('User', backref='bookings', lazy=True)
    showtime = db.relationship('Showtime', backref='bookings', lazy=True)

class Review(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    movie_id = db.Column(db.Integer, db.ForeignKey("movie.id"), nullable=False)
    rating = db.Column(db.Integer, nullable=False)
    comment = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    user = db.relationship("User", backref=db.backref("reviews", lazy=True))
    movie = db.relationship("Movie", backref=db.backref("reviews", lazy=True, cascade="all, delete-orphan"))

# ==============================================================================
# HELPER FUNCTIONS & DECORATORS
# ==============================================================================
def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        user = session.get("user")
        if not user or user.get("role") != "admin":
            flash("Admin access is required for this page.", "danger")
            return redirect(url_for("index"))
        return f(*args, **kwargs)
    return decorated_function
    
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

def create_seat_layout(rows, cols, seat_categories=None):
    layout = np.zeros((int(rows), int(cols)), dtype=int).tolist()
    if seat_categories:
        for cat, positions in seat_categories.items():
            for r, c in positions:
                if 0 <= r < int(rows) and 0 <= c < int(cols):
                    if cat.lower() == "premium": layout[r][c] = 2
                    elif cat.lower() == "vip": layout[r][c] = 4
    return layout

def get_seat_type(code):
    if code in {0, 1}: return "Standard"
    if code in {2, 3}: return "Premium"
    if code in {4, 5}: return "VIP"
    return "Unknown"

def get_seat_price(showtime, seat_type):
    if seat_type == "Premium": return float(showtime.price_premium)
    if seat_type == "VIP": return float(showtime.price_vip)
    return float(showtime.price_standard)

def generate_ticket_pdf(booking):
    buffer = BytesIO()
    p = canvas.Canvas(buffer, pagesize=A4)
    width, height = A4

    # --- TICKET STYLING ---
    # Draw a border for the ticket
    p.setStrokeColorRGB(0.2, 0.2, 0.2)
    p.rect(80, height - 400, width - 160, 300)

    # Title
    p.setFont("Helvetica-Bold", 24)
    p.drawCentredString(width / 2, height - 150, "CineBook Admission Ticket")
    
    # Movie Title
    p.setFont("Helvetica-Bold", 18)
    p.drawCentredString(width / 2, height - 200, booking.showtime.movie.title)

    # Line separator
    p.line(100, height - 220, width - 100, height - 220)

    # Booking Details
    p.setFont("Helvetica", 12)
    p.drawString(100, height - 250, f"Showtime: {booking.showtime.time.strftime('%A, %d %b %Y at %I:%M %p')}")
    p.drawString(100, height - 270, f"Hall: {booking.showtime.hall}")
    p.drawString(100, height - 290, f"Booked for: {booking.user.full_name or booking.user.username}")

    # Seats
    p.setFont("Helvetica-Bold", 12)
    p.drawString(100, height - 320, "Seats:")
    p.setFont("Helvetica", 12)
    seats_str = ", ".join([f"R{s['row']+1}-S{s['col']+1} ({s['type']})" for s in json.loads(booking.seats)])
    p.drawString(120, height - 340, seats_str)

    # Booking ID and Price
    p.setFont("Helvetica-Bold", 14)
    p.drawString(width - 250, height - 250, f"Total Price: ${booking.total_price:.2f}")
    
    # Use 5-digit padded ID
    booking_id_str = f"{booking.id:05d}"
    p.setFont("Helvetica-Bold", 16)
    p.drawRightString(width - 100, height - 380, f"Booking ID: {booking_id_str}")
    
    p.showPage()
    p.save()
    buffer.seek(0)
    return buffer

def send_email(recipient, subject, html_body, pdf_attachment=None, filename=None):
    if not all([app.config.get("MAIL_USERNAME"), app.config.get("MAIL_PASSWORD")]):
        app.logger.warning("Email not configured. Skipping email dispatch.")
        return
    msg = MIMEMultipart()
    msg["From"], msg["To"], msg["Subject"] = app.config["MAIL_USERNAME"], recipient, subject
    msg.attach(MIMEText(html_body, "html"))
    if pdf_attachment and filename:
        part = MIMEApplication(pdf_attachment.read(), _subtype="pdf")
        part.add_header("Content-Disposition", "attachment", filename=filename)
        msg.attach(part)
    try:
        with smtplib.SMTP(app.config["MAIL_SERVER"], app.config["MAIL_PORT"]) as server:
            server.starttls()
            server.login(app.config["MAIL_USERNAME"], app.config["MAIL_PASSWORD"])
            server.sendmail(app.config["MAIL_USERNAME"], recipient, msg.as_string())
    except Exception as e:
        app.logger.error(f"Failed to send email to {recipient}: {e}")

@app.template_filter("fromjson")
def from_json_filter(value):
    try: return json.loads(value)
    except: return {}

# ==============================================================================
# USER-FACING ROUTES
# ==============================================================================

@app.route("/")
def index():
    movies = Movie.query.filter_by(is_active=True).order_by(Movie.rating.desc()).limit(4).all()
    today = datetime.now().date()
    tomorrow = today + timedelta(days=1)
    today_showtimes = Showtime.query.filter(db.func.date(Showtime.time) == today).order_by(Showtime.time).all()
    tomorrow_showtimes = Showtime.query.filter(db.func.date(Showtime.time) == tomorrow).order_by(Showtime.time).all()
    return render_template("index.html", now_showing=movies, user=session.get("user"), today_showtimes=today_showtimes, tomorrow_showtimes=tomorrow_showtimes)

@app.route("/movies")
def movies():
    search_query = request.args.get('search', '')
    selected_genre = request.args.get('genre', 'all')
    
    query = Movie.query.filter_by(is_active=True)
    
    if search_query:
        query = query.filter(Movie.title.ilike(f'%{search_query}%'))
    
    if selected_genre != 'all':
        query = query.filter_by(genre=selected_genre)
        
    movies_list = query.all()
    
    # Get all unique genres for the filter dropdown
    genres = sorted(list(set(m.genre for m in Movie.query.filter_by(is_active=True).all())))

    return render_template("movies.html", movies=movies_list, user=session.get("user"), 
                           genres=genres, selected_genre=selected_genre, search_query=search_query)

@app.route("/movie/<int:movie_id>")
def movie_detail(movie_id):
    movie = db.get_or_404(Movie, movie_id)
    start_dt = datetime.combine(datetime.now().date(), dtime.min)
    showtimes = Showtime.query.filter(Showtime.movie_id == movie_id, Showtime.time >= start_dt).order_by(Showtime.time).all()
    showtimes_by_date = {}
    for st in showtimes:
        showtimes_by_date.setdefault(st.time.strftime("%A, %d %B %Y"), []).append(st)
    reviews = Review.query.filter_by(movie_id=movie_id).order_by(Review.created_at.desc()).all()
    avg_rating = db.session.query(db.func.avg(Review.rating)).filter_by(movie_id=movie_id).scalar() or 0
    user_review = None
    if "user_id" in session:
        user_review = Review.query.filter_by(movie_id=movie_id, user_id=session["user_id"]).first()
    return render_template(
        "movie_detail.html", movie=movie, showtimes_by_date=showtimes_by_date,
        reviews=reviews, avg_rating=round(avg_rating, 1),
        user_review=user_review, user=session.get("user")
    )

@app.route("/showtime/<int:showtime_id>")
def showtime_detail(showtime_id):
    showtime = db.get_or_404(Showtime, showtime_id)
    layout = "[]"
    if showtime.seat_layout:
        layout = showtime.seat_layout.layout
    return render_template("showtime.html", showtime=showtime, layout=layout, movie=showtime.movie, user=session.get("user"))

@app.route("/process-payment", methods=["POST"])
def process_payment():
    if "user_id" not in session:
        return jsonify({"success": False, "message": "Please login to book tickets."}), 401
    try:
        data = request.get_json()
        showtime = db.get_or_404(Showtime, int(data["showtime_id"]))
        seat_layout_obj = SeatLayout.query.filter_by(showtime_id=showtime.id).first()
        if not seat_layout_obj:
            return jsonify({"success": False, "message": "Seat layout not available for this show."}), 500
        layout = json.loads(seat_layout_obj.layout)
        total_price, booking_seats = 0.0, []
        for seat in data.get("seats", []):
            r, c = int(seat["row"]), int(seat["col"])
            if layout[r][c] % 2 != 0:
                return jsonify({"success": False, "message": f"Seat R{r+1}C{c+1} is already taken."}), 409
            seat_type = get_seat_type(layout[r][c])
            price = get_seat_price(showtime, seat_type)
            total_price += price
            booking_seats.append({"row": r, "col": c, "type": seat_type, "price": price})
            layout[r][c] += 1
        seat_layout_obj.layout = json.dumps(layout)
        booking = Booking(user_id=session["user_id"], showtime_id=showtime.id, seats=json.dumps(booking_seats), total_price=total_price)
        db.session.add(booking)
        db.session.commit()
        user = db.session.get(User, session["user_id"])
        email_body = render_template("email/booking_confirmation.html", user=user, booking=booking)
        pdf_ticket = generate_ticket_pdf(booking)
        send_email(user.email, f"Your Ticket for {showtime.movie.title}", email_body, pdf_ticket, f"ticket_{booking.id}.pdf")
        return jsonify({"success": True, "booking_id": booking.id})
    except Exception as e:
        db.session.rollback()
        app.logger.error(f"Payment Error: {e}")
        return jsonify({"success": False, "message": "An unexpected error occurred."}), 500

@app.route("/booking-confirmation/<int:booking_id>")
def booking_confirmation(booking_id):
    booking = db.get_or_404(Booking, booking_id)
    if booking.user_id != session.get("user_id") and session.get("user", {}).get("role") != "admin":
        flash("You are not authorized to view this confirmation.", "danger")
        return redirect(url_for("index"))
    return render_template("booking_confirmation.html", booking=booking, user=session.get("user"))

@app.route("/my_bookings")
def my_bookings():
    if "user_id" not in session:
        flash("Please log in to see your bookings.", "warning")
        return redirect(url_for('login'))
    bookings = Booking.query.filter_by(user_id=session["user_id"]).order_by(Booking.booking_time.desc()).all()
    # Inga 'user=session.get("user")' add panni irukken paathukonga
    return render_template("my_bookings.html", bookings=bookings, now=datetime.utcnow(), buffer_time=timedelta(hours=2), user=session.get("user"))

@app.route("/download_ticket/<int:booking_id>")
def download_ticket(booking_id):
    if "user_id" not in session: return redirect(url_for("login"))
    booking = db.get_or_404(Booking, booking_id)
    if booking.user_id != session["user_id"]:
        flash("You are not authorized to download this ticket.", "danger")
        return redirect(url_for("my_bookings"))
    try:
        pdf_buffer = generate_ticket_pdf(booking)
        filename = f"CineBook_Ticket_{booking.id:05d}.pdf"
        return send_file(pdf_buffer, as_attachment=True, download_name=filename, mimetype="application/pdf")
    except Exception as e:
        app.logger.error(f"PDF Download Error: {e}")
        flash("Could not generate your ticket at this time. Please try again later.", "danger")
        return redirect(url_for("my_bookings"))

@app.route("/booking/<int:booking_id>/cancel")
def cancel_booking(booking_id):
    if "user_id" not in session: return redirect(url_for("login"))
    booking = db.get_or_404(Booking, booking_id)
    if booking.user_id != session["user_id"]:
        flash("Unauthorized action.", "danger")
        return redirect(url_for("my_bookings"))
    if booking.showtime.time < datetime.utcnow() + timedelta(hours=2):
        flash("Tickets can only be cancelled up to 2 hours before showtime.", "warning")
        return redirect(url_for("my_bookings"))
    if booking.status == 'cancelled':
        flash("This booking is already cancelled.", "info")
        return redirect(url_for("my_bookings"))
    try:
        booking.status = "cancelled"
        seat_layout_obj = SeatLayout.query.filter_by(showtime_id=booking.showtime_id).first()
        if seat_layout_obj:
            layout = json.loads(seat_layout_obj.layout)
            for seat in json.loads(booking.seats):
                r, c = int(seat["row"]), int(seat["col"])
                if layout[r][c] % 2 != 0: layout[r][c] -= 1
            seat_layout_obj.layout = json.dumps(layout)
        db.session.commit()
        user = db.session.get(User, session["user_id"])
        email_body = render_template("email/booking_cancellation.html", user=user, booking=booking)
        send_email(user.email, f"Cancellation Confirmation for {booking.showtime.movie.title}", email_body)
        flash("Booking successfully cancelled.", "success")
    except Exception as e:
        db.session.rollback()
        app.logger.error(f"Cancellation Error: {e}")
        flash("An error occurred during cancellation.", "danger")
    return redirect(url_for("my_bookings"))

# ==============================================================================
# AUTHENTICATION & REVIEW ROUTES
# ==============================================================================
@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username, email = request.form["username"].strip(), request.form["email"].strip()
        if User.query.filter((User.username == username) | (User.email == email)).first():
            flash("Username or email already exists.", "danger")
            return redirect(url_for("register"))
        user = User(username=username, email=email, full_name=request.form.get("full_name"))
        user.set_password(request.form["password"])
        db.session.add(user)
        db.session.commit()
        flash("Account created! Please log in.", "success")
        return redirect(url_for("login"))
    return render_template("register.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        user = User.query.filter_by(username=request.form["username"]).first()
        if user and user.check_password(request.form["password"]):
            session["user_id"] = user.id
            session["user"] = {"id": user.id, "username": user.username, "role": user.role, "avatar": user.avatar}
            flash("Login successful!", "success")
            return redirect(url_for("index"))
        flash("Invalid username or password.", "danger")
    return render_template("login.html")

@app.route("/login/google")
def login_google():
    redirect_uri = url_for("authorize_google", _external=True)
    return oauth.google.authorize_redirect(redirect_uri)

@app.route("/authorize/google")
def authorize_google():
    try:
        token = oauth.google.authorize_access_token()
        user_info = token.get('userinfo')
        if not user_info or 'email' not in user_info:
            flash("Google login failed. Could not retrieve user information.", "danger")
            return redirect(url_for("login"))
        user = User.query.filter_by(email=user_info['email']).first()
        if not user:
            user = User(
                username=user_info['email'].split('@')[0], 
                email=user_info['email'],
                full_name=user_info.get('name'), 
                avatar=user_info.get('picture'), 
                provider='google'
            )
            db.session.add(user)
            db.session.commit()
        session["user_id"] = user.id
        session["user"] = {"id": user.id, "username": user.username, "role": user.role, "avatar": user.avatar}
        flash("Logged in successfully with Google!", "success")
        return redirect(url_for("index"))
    except Exception as e:
        app.logger.error(f"Google Auth Error: {e}")
        flash("An error occurred during Google authentication.", "danger")
        return redirect(url_for("login"))

@app.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out.", "info")
    return redirect(url_for("index"))
    
@app.route("/movie/<int:movie_id>/review", methods=["POST"])
def add_review(movie_id):
    if "user_id" not in session:
        flash("Please login to submit a review.", "warning")
        return redirect(url_for("login"))
    existing_review = Review.query.filter_by(movie_id=movie_id, user_id=session["user_id"]).first()
    rating = request.form.get("rating", type=int)
    comment = request.form.get("comment", "").strip()
    if not rating or not comment:
        flash("Rating and comment are required.", "danger")
        return redirect(url_for("movie_detail", movie_id=movie_id))
    if existing_review:
        existing_review.rating = rating
        existing_review.comment = comment
        flash("Your review has been updated.", "success")
    else:
        new_review = Review(user_id=session["user_id"], movie_id=movie_id, rating=rating, comment=comment)
        db.session.add(new_review)
        flash("Thank you for your review!", "success")
    db.session.commit()
    return redirect(url_for("movie_detail", movie_id=movie_id))

# ==============================================================================
# ADMIN ROUTES (FULLY IMPLEMENTED)
# ==============================================================================
@app.route("/admin")
@admin_required
def admin_dashboard():
    total_movies = Movie.query.count()
    total_bookings = Booking.query.count()
    total_users = User.query.count()
    total_revenue = db.session.query(db.func.sum(Booking.total_price)).filter(Booking.status == 'confirmed').scalar() or 0
    recent_bookings = Booking.query.order_by(Booking.booking_time.desc()).limit(5).all()
    return render_template("admin/dashboard.html", total_movies=total_movies, total_bookings=total_bookings,
                           total_users=total_users, total_revenue=round(total_revenue, 2), 
                           recent_bookings=recent_bookings, user=session.get("user"))

@app.route("/admin/movies")
@admin_required
def admin_movies():
    movies = Movie.query.all()
    return render_template("admin/movies.html", movies=movies, user=session.get("user"))

@app.route("/admin/movies/add", methods=['GET', 'POST'])
@admin_required
def admin_add_movie():
    if request.method == 'POST':
        title = request.form.get('title')
        if Movie.query.filter_by(title=title).first():
            flash('Movie with this title already exists.', 'danger')
            return redirect(url_for('admin_add_movie'))
        
        poster_url = "/static/images/default-poster.png"
        if 'poster' in request.files:
            file = request.files['poster']
            if file and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
                poster_url = url_for('static', filename=f'uploads/{filename}')

        new_movie = Movie(
            title=title,
            genre=request.form.get('genre'),
            duration=request.form.get('duration', type=int),
            language=request.form.get('language'),
            rating=request.form.get('rating', type=float),
            director=request.form.get('director'),
            cast=json.dumps([c.strip() for c in request.form.get('cast', '').split(',')]),
            trailer_url=request.form.get('trailer_url'),
            description=request.form.get('description'),
            poster_url=poster_url
        )
        db.session.add(new_movie)
        db.session.commit()
        flash('Movie added successfully!', 'success')
        return redirect(url_for('admin_movies'))
    
    return render_template("admin/add_movie.html", user=session.get("user"))

@app.route("/admin/showtimes")
@admin_required
def admin_showtimes():
    showtimes = Showtime.query.order_by(Showtime.time.desc()).all()
    return render_template("admin/showtimes.html", showtimes=showtimes, user=session.get("user"))

@app.route("/admin/showtimes/add", methods=['GET', 'POST'])
@admin_required
def admin_add_showtime():
    if request.method == 'POST':
        showtime = Showtime(
            movie_id=request.form.get('movie_id', type=int),
            time=datetime.fromisoformat(request.form.get('time')),
            hall=request.form.get('hall'),
            rows=request.form.get('rows', type=int),
            cols=request.form.get('cols', type=int),
            price_standard=request.form.get('price_standard', type=float),
            price_premium=request.form.get('price_premium', type=float),
            price_vip=request.form.get('price_vip', type=float),
        )
        db.session.add(showtime)
        db.session.flush() # To get the showtime.id for the layout
        
        layout_data = create_seat_layout(showtime.rows, showtime.cols)
        seat_layout = SeatLayout(showtime_id=showtime.id, layout=json.dumps(layout_data))
        db.session.add(seat_layout)
        
        db.session.commit()
        flash('Showtime added successfully!', 'success')
        return redirect(url_for('admin_showtimes'))

    movies = Movie.query.filter_by(is_active=True).all()
    return render_template("admin/add_showtime.html", movies=movies, user=session.get("user"))

@app.route("/admin/bookings")
@admin_required
def admin_bookings():
    bookings = Booking.query.order_by(Booking.booking_time.desc()).all()
    return render_template("admin/bookings.html", bookings=bookings, user=session.get("user"))

@app.route("/admin/users")
@admin_required
def admin_users():
    users = User.query.all()
    return render_template("admin/users.html", users=users, user=session.get("user"))

@app.route("/admin/verify-ticket", methods=["GET", "POST"])
@admin_required
def admin_verify_ticket():
    booking = None
    if request.method == "POST":
        booking_id = request.form.get("booking_id")
        if booking_id:
            booking = Booking.query.get(int(booking_id))
            if not booking:
                flash(f"Booking with ID {booking_id} not found.", "danger")
        else:
            flash("Please provide a Booking ID.", "warning")
    return render_template("admin/verify_ticket.html", user=session.get("user"), booking=booking)

@app.route("/admin/mark-attended/<int:booking_id>", methods=["POST"])
@admin_required
def admin_mark_attended(booking_id):
    booking = Booking.query.get(booking_id)
    if not booking:
        flash("Booking not found.", "danger")
        return redirect(url_for('admin_verify_ticket'))

    if booking.attended:
        flash(f"Booking ID {booking.id:05d} has already been marked as attended.", "warning")
    else:
        booking.attended = True
        db.session.commit()
        flash(f"Booking ID {booking.id:05d} marked as attended successfully.", "success")
    
    # Re-render the verify page with the same booking details to show the updated status
    return render_template("admin/verify_ticket.html", user=session.get("user"), booking=booking)

# ==============================================================================
# DATABASE INITIALIZATION & APP EXECUTION
# ==============================================================================
def init_db():
    # This function seeds the database with initial data
    if User.query.count() > 0: # Check if any user exists, assumes db is seeded
        return
        
    print("Seeding database with initial data...")
    # Add Admin
    admin = User(username="admin", email="admin@app.com", role="admin")
    admin.set_password("admin")
    db.session.add(admin)

    # Add Normal User
    user1 = User(username="testuser", email="user@app.com", role="user")
    user1.set_password("password")
    db.session.add(user1)
    
    # Add Movies
    movies_data = [
        Movie(title="Avatar: The Way of Water", genre="Sci-Fi", duration=192, rating=8.5, description="Jake Sully and Ney'tiri have formed a family...", poster_url="/static/images/avatar.jpg", cast=json.dumps(["Sam Worthington", "Zoe Saldaña"]), director="James Cameron"),
        Movie(title="John Wick: Chapter 4", genre="Action", duration=169, rating=8.2, description="John Wick takes his fight against the High Table global...", poster_url="/static/images/johnwick.jpg", cast=json.dumps(["Keanu Reeves", "Donnie Yen"]), director="Chad Stahelski"),
        Movie(title="Oppenheimer", genre="Biographical", duration=180, rating=9.0, description="The story of American scientist J. Robert Oppenheimer...", poster_url="/static/images/oppenheimer.jpg", cast=json.dumps(["Cillian Murphy", "Emily Blunt"]), director="Christopher Nolan"),
        Movie(title="The Super Mario Bros. Movie", genre="Animation", duration=92, rating=7.8, description="The story of The Super Mario Bros. on their journey through the Mushroom Kingdom.", poster_url="/static/images/mario.jpg", cast=json.dumps(["Chris Pratt", "Anya Taylor-Joy"]), director="Aaron Horvath"),
    ]
    db.session.bulk_save_objects(movies_data)
    db.session.commit() # Commit to get movie IDs

    # --- START: ADDED SHOWTIME SEEDING ---
    movies = Movie.query.all()
    halls = ["Hall A", "Hall B", "Hall C"]
    today = datetime.now().date()
    
    for i in range(3): # Create showtimes for today and next 2 days
        current_date = today + timedelta(days=i)
        for movie in movies:
            # Create 3 showtimes per movie per day
            showtime_times = [dtime(14, 30), dtime(18, 0), dtime(21, 30)]
            for st_time in showtime_times:
                showtime_dt = datetime.combine(current_date, st_time)
                
                showtime = Showtime(
                    movie_id=movie.id,
                    time=showtime_dt,
                    hall=halls[movies.index(movie) % len(halls)],
                    rows=8,
                    cols=12,
                    price_standard=10.0,
                    price_premium=15.0,
                    price_vip=20.0
                )
                db.session.add(showtime)
                db.session.flush() # Get ID for layout
                
                # Create a simple seat layout (rows 6,7 are premium, row 8 is VIP)
                layout_data = create_seat_layout(
                    showtime.rows, showtime.cols,
                    seat_categories={
                        "premium": [(r, c) for r in range(5, 7) for c in range(12)],
                        "vip": [(r, c) for r in range(7, 8) for c in range(2, 10)]
                    }
                )
                seat_layout = SeatLayout(showtime_id=showtime.id, layout=json.dumps(layout_data))
                db.session.add(seat_layout)
    # --- END: ADDED SHOWTIME SEEDING ---

    db.session.commit()
    print("Database seeded successfully.")

if __name__ == "__main__":
    with app.app_context():
        # os.remove('instance/cinema.db') # Uncomment to force re-creation of DB on every run
        os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
        db.create_all()
        init_db()
    app.run(debug=True, port=5000)