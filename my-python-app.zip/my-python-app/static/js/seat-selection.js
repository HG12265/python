document.addEventListener('DOMContentLoaded', function() {
    console.log('✅ Seat selection (dummy payment) script loaded');

    // Elements
    const seatContainer = document.getElementById('seat-map');
    const selectedCountEl = document.getElementById('selected-count');
    const selectedTotalEl = document.getElementById('selected-total');
    const payButton = document.getElementById('pay-button');

    // Read seat layout and prices from data attributes
    const showtimeId = parseInt(seatContainer.dataset.showtimeId);
    const layout = JSON.parse(seatContainer.dataset.layout || '[]');
    const priceStandard = parseFloat(seatContainer.dataset.priceStandard || 0);
    const pricePremium = parseFloat(seatContainer.dataset.pricePremium || 0);
    const priceVip = parseFloat(seatContainer.dataset.priceVip || 0);

    // Render seats as a table of buttons
    function renderSeats() {
        seatContainer.innerHTML = '';
        const table = document.createElement('div');
        table.className = 'seat-grid';
        for (let r = 0; r < layout.length; r++) {
            const rowDiv = document.createElement('div');
            rowDiv.className = 'seat-row';
            for (let c = 0; c < layout[r].length; c++) {
                const cell = document.createElement('button');
                cell.type = 'button';
                cell.className = 'seat';
                cell.dataset.row = r;
                cell.dataset.col = c;
                const code = layout[r][c];
                if (code % 2 === 1) {
                    cell.classList.add('booked');
                    cell.disabled = true;
                    cell.textContent = 'X';
                } else {
                    // available
                    const t = getSeatType(code);
                    cell.classList.add(t.toLowerCase());
                    cell.textContent = (r+1) + '-' + (c+1);
                    cell.addEventListener('click', toggleSeat);
                }
                rowDiv.appendChild(cell);
            }
            table.appendChild(rowDiv);
        }
        seatContainer.appendChild(table);
        updateSummary();
    }

    function getSeatType(code) {
        if ([0,1].includes(code)) return 'Standard';
        if ([2,3].includes(code)) return 'Premium';
        if ([4,5].includes(code)) return 'VIP';
        return 'Standard';
    }

    function getSeatPriceByType(type) {
        if (type === 'Standard') return priceStandard;
        if (type === 'Premium') return pricePremium;
        if (type === 'VIP') return priceVip;
        return priceStandard;
    }

    function toggleSeat(e) {
        const btn = e.currentTarget;
        btn.classList.toggle('selected');
        updateSummary();
    }

    function updateSummary() {
        const selected = Array.from(seatContainer.querySelectorAll('.seat.selected'));
        selectedCountEl.textContent = selected.length;
        let total = 0;
        selected.forEach(btn => {
            const r = parseInt(btn.dataset.row);
            const c = parseInt(btn.dataset.col);
            const price = getSeatPriceByType(getSeatType(layout[r][c]));
            total += price;
        });
        selectedTotalEl.textContent = total.toFixed(2);
    }

    payButton.addEventListener('click', function() {
        const selected = Array.from(seatContainer.querySelectorAll('.seat.selected'));
        if (selected.length === 0) {
            alert('Please select at least one seat.');
            return;
        }
        payButton.disabled = true;
        payButton.textContent = 'Processing...';

        const seats = selected.map(btn => ({row: parseInt(btn.dataset.row), col: parseInt(btn.dataset.col)}));

        fetch('/process-payment', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({showtime_id: showtimeId, seats: seats, payment_method: 'dummy'})
        })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                // on success, redirect to booking confirmation or success page
                window.location.href = '/booking/success?booking_id=' + data.booking_id;
            } else {
                alert('Booking failed: ' + data.message);
                payButton.disabled = false;
                payButton.textContent = 'Pay (Dummy)';
            }
        })
        .catch(err => {
            console.error('Payment error', err);
            alert('An error occurred. See console for details.');
            payButton.disabled = false;
            payButton.textContent = 'Pay (Dummy)';
        });
    });

    // initial render
    renderSeats();
});
